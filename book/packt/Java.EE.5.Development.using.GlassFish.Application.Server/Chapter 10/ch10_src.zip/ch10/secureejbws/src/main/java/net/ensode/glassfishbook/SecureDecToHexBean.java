package net.ensode.glassfishbook;

import javax.ejb.Stateless;
import javax.jws.WebService;

@Stateless
@WebService
public class SecureDecToHexBean
{ 
  public String convertDecToHex(int i)
  {
    return Integer.toHexString(i);
  }
}
