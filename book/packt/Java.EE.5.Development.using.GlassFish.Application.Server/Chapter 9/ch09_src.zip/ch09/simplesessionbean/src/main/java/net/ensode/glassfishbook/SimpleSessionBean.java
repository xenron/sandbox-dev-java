package net.ensode.glassfishbook;

import javax.ejb.Stateless;

@Stateless
public class SimpleSessionBean implements SimpleSession
{  
  private String message = "If you don't see this, it didn't work!";
  
  public String getMessage()
  {
    return message;
  }
}
