package net.ensode.glassfishbook.jsfjpa;

import javax.ejb.EJB;

import net.ensode.glassfishbook.Customer;
import net.ensode.glassfishbook.CustomerDao;

public class CustomerController
{
  @EJB
  CustomerDao customerDao;
  
  private Customer customer;

  public String saveCustomer()
  {
    String returnValue = "success";

    try
    {      
      customerDao.saveCustomer(customer);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      returnValue = "failure";
    }

    return returnValue;
  }

  public Customer getCustomer()
  {
    return customer;
  }

  public void setCustomer(Customer customer)
  {
    this.customer = customer;
  }
}
