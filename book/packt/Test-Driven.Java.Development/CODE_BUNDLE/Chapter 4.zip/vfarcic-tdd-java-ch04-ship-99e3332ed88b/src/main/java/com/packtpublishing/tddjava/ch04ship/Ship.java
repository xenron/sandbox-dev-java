package com.packtpublishing.tddjava.ch04ship;

public class Ship {

}
