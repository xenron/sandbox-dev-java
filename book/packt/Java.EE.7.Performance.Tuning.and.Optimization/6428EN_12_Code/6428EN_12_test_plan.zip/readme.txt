The .jmx files are the files we used in JMeter in chapter 12 to do load test of our Excellent Survey - create new survey transaction.

You can use them by the following steps:
1- Run JMeter
2- File --> Open --> and select any of these files
3- Point to the correct .csv files from "CSV Data Set Config- load username/password" elements to the included files: survey_users.csv
4- Run the required services : mySQL and Glassfish server
5- Execute the test plans.
