/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */
package osa.ora.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.imageio.ImageIO;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import osa.ora.beans.Configuration;
import osa.ora.dao.helper.IConstant;

/**
 *
 * @author Osama Oransa
 */
public class EmailSender {

    private String smtpServerIP="";
    private String smtpServerPort="";
    private boolean useSSL = true;
    private String smtpServerUser="";
    private String smtpServerPassword="";
    private boolean initialized=false;
    /**
     * singleton variable
     */
    final private static EmailSender emailSender= new EmailSender();
    /**
     * get singleton method
     * @return 
     */
    public static EmailSender getInstance(){
        return emailSender;
    }
    /**
     * private constructor
     */
    private EmailSender(){
    }

    /**
     * this public method used to send the mail in a thread
     * @param toUserEmail
     * @param subject
     * @param body
     * @param myImage
     * @param file
     * @param isPicture
     */
    public void sendMail(final String[] toUserEmail, final String subject, final String body,
            final BufferedImage myImage, final File file, final boolean isPicture) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", smtpServerIP);
            props.put("mail.smtp.port", smtpServerPort);
            props.put("mail.smtp.auth", "true");
            //props.put("mail.debug", "false");
            props.put("mail.smtp.socketFactory.port", smtpServerPort);
            //next attributes for google gmail for SSL
            if (useSSL) {
                props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                props.put("mail.smtp.socketFactory.fallback", "false");
            }
            Authenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            //session.setDebug(false);
            // create a message
            Message msg = new MimeMessage(session);
            msg.setHeader("Excellent Survey", "By Osama Oransa");
            // set the from and to address
            InternetAddress addressFrom = new InternetAddress(smtpServerUser);
            msg.setFrom(addressFrom);
            InternetAddress[] addressTo = new InternetAddress[toUserEmail.length];
            for (int i = 0; i < toUserEmail.length; i++) {
                addressTo[i] = new InternetAddress(toUserEmail[i]);
            }
            msg.setRecipients(Message.RecipientType.TO, addressTo);
            String[] messageParts = body.split("##");
            //no thing attached
            if (messageParts.length == 1) {
                msg.setContent(body, "text/html");
                //image is attached
                //body is text and image
            } else if (messageParts.length == 2) {
                MimeMultipart multipart = new MimeMultipart();//"related");
                MimeBodyPart messageBodyPart;
                // first part html text before image
                messageBodyPart = new MimeBodyPart();
                if (isPicture) {
                    messageBodyPart.setContent(messageParts[0] + "<br><img src=\"cid:image\"><br>" + messageParts[1], "text/html");
                    multipart.addBodyPart(messageBodyPart);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    boolean readingImageResult;
                    try {
                        readingImageResult = ImageIO.write(myImage, "jpg", byteArrayOutputStream);
                        Logger.getLogger(EmailSender.class.getName()).log(Level.INFO,"Result of writing the image is " + readingImageResult);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                    MimeBodyPart messageBodyPart2 = new MimeBodyPart();
                    DataSource fds = new ByteArrayDataSource(byteArray, "image/jpg");
                    messageBodyPart2.setDataHandler(new DataHandler(fds));
                    messageBodyPart2.setHeader("Content-ID", "<image>");
                    multipart.addBodyPart(messageBodyPart2);
                    msg.setContent(multipart);
                } else {
                    //is file attached, like voice....
                    messageBodyPart.setContent(messageParts[0] + "<br>" + messageParts[1], "text/html");
                    multipart.addBodyPart(messageBodyPart);
                    // Part two is attachment
                    MimeBodyPart messageBodyPart2 = new MimeBodyPart();
                    DataSource source = new FileDataSource(file);
                    messageBodyPart2.setDataHandler(new DataHandler(source));
                    messageBodyPart2.setFileName(file.getName());
                    multipart.addBodyPart(messageBodyPart2);
                    msg.setContent(multipart);
                }
            }
            // Setting the Subject and Content Type
            msg.setSubject(subject);
            Transport.send(msg);
            Logger.getLogger(EmailSender.class.getName()).log(Level.INFO,"Message sent to " + toUserEmail + " OK.");
        } catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(EmailSender.class.getName()).log(Level.INFO,"Exception " + ex);
        }
    }
    /**
     * @return the initialized
     */
    public boolean isInitialized() {
        return initialized;
    }

    /**
     * @param initialized the initialized to set
     */
    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public void init(Configuration[] configs) {
        for(Configuration config:configs){
            switch (config.getConfigkey()) {
                case IConstant.EMAIL_SERVER:
                    smtpServerIP=config.getConfigValue();
                    break;
                case IConstant.EMAIL_SERVER_PORT:
                    smtpServerPort=config.getConfigValue();
                    break;
                case IConstant.SSL:
                    useSSL=Boolean.parseBoolean(config.getConfigValue());
                    break;
                case IConstant.EMAIL_SERVER_USER:
                    smtpServerUser=config.getConfigValue();
                    break;
                case IConstant.EMAIL_SERVER_PASSWORD:
                    smtpServerPassword=config.getConfigValue();
                    break;
            }
        }
    }
    // inner class that is used for authentication purposes
    private class SMTPAuthenticator extends javax.mail.Authenticator {
        @Override
        public PasswordAuthentication getPasswordAuthentication() {
            Logger.getLogger(EmailSender.class.getName()).log(Level.INFO,"call authentication");
            String username = smtpServerUser;
            String password = smtpServerPassword;
            return new PasswordAuthentication(username, password);
        }
    }
}
