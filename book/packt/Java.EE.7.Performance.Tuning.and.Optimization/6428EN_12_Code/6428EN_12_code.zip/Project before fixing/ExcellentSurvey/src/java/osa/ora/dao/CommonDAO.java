/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dao;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.Configuration;
import osa.ora.beans.NotificationTemplate;
import osa.ora.dao.helper.DAOHelper;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.ConfigurationVO;
import osa.ora.util.EmailSender;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class CommonDAO {
    @EJB(beanName = "DAOHelper")
    DAOHelper helper;
    EmailSender emailSender= EmailSender.getInstance();
    /**
     * create audit trail for a user action
     * @param auditVO 
     */
    public void createAuditTrail(AuditTrailVO auditVO){
        helper.createAuditTrail(auditVO);
    }
    /**
     * get notification for action
     * @param actionId
     * @return 
     */
    public NotificationTemplate getNotificationForAction(int actionId) {
        return helper.getNotificationForAction(actionId);
    }
    /**
     * replace notification parameters
     * @param body
     * @param parameters
     * @return 
     */
    public String replaceParameters(String body, String[] parameters) {
        Logger.getLogger(CommonDAO.class.getName()).log(Level.INFO,"initial="+body);
        for(int i=0;i<parameters.length;i++){
            Logger.getLogger(CommonDAO.class.getName()).log(Level.INFO,"Parm "+i+"="+parameters[i]);
            String current="%"+i;
            int n=body.indexOf(current);
            Logger.getLogger(CommonDAO.class.getName()).log(Level.INFO,"n="+n+" current="+current);
            if(n!=-1) body=body.substring(0,n)+parameters[i]+body.substring(n+2);
            Logger.getLogger(CommonDAO.class.getName()).log(Level.INFO,"n="+body);
        }
        return body;
    }
    /**
     * get email configurations
     * @return 
     */
    public Configuration[] getEmailConfig() {
        return helper.getEmailConfig();
    }
    /**
     * set email configurations
     * @param configVO
     * @return 
     */
    public boolean setEmailConfig(ConfigurationVO[] configVO) {
        return helper.setEmailConfig(configVO);
    }
    /**
     * send email method
     * @param toUserEmail
     * @param subject
     * @param body
     * @param myImage
     * @param file
     * @param isPicture 
     */
    public void sendMail(final String[] toUserEmail, final String subject, final String body,
            final BufferedImage myImage, final File file, final boolean isPicture) {
        if(!emailSender.isInitialized()){
            Configuration[] configs=getEmailConfig();
            if(configs!=null) {
                emailSender.init(configs);
                emailSender.setInitialized(true);
            }
        }
        Logger.getLogger(CommonDAO.class.getName()).log(Level.INFO,"Email subject="+subject+", body="+body);
        emailSender.sendMail(toUserEmail, subject, body, myImage, file, isPicture);
    }    
}
