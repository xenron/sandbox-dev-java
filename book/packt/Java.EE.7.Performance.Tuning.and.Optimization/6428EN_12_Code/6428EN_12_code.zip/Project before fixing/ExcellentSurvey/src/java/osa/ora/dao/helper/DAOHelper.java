/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */
package osa.ora.dao.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import osa.ora.beans.AuditTrail;
import osa.ora.beans.Autogen;
import osa.ora.beans.Configuration;
import osa.ora.beans.NotificationTemplate;
import osa.ora.beans.QuestionRatingType;
import osa.ora.beans.Questions;
import osa.ora.beans.Survey;
import osa.ora.beans.SurveyEmails;
import osa.ora.beans.SurveyQuestions;
import osa.ora.beans.SurveyQuestionsPK;
import osa.ora.beans.SurveyReports;
import osa.ora.beans.SurveyStatus;
import osa.ora.beans.User;
import osa.ora.beans.UserAnswers;
import osa.ora.beans.UserAnswersPK;
import osa.ora.beans.UserRoles;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.ConfigurationVO;
import osa.ora.dto.QuestionVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless(name = "DAOHelper")
public class DAOHelper {

    @PersistenceContext(unitName = "SurveyOnePU")
    EntityManager em;

    /**
     * login a customer
     *
     * @param username
     * @param password
     * @return
     */
    public User login(String username, String password) {
        Query query = em.createNamedQuery("User.findByNamePassword");
        query.setParameter("name", username);
        query.setParameter("password", password);
        List<User> results = query.getResultList();
        if (results != null && results.size() > 0) {
            return results.get(0);
        }
        return null;
    }

    /**
     * check if user already exist, user and email already exist?
     *
     * @param username
     * @param email
     * @return
     */
    private User checkUserExist(String username, String email) {
        Query query = em.createNamedQuery("User.findByNameEmail");
        query.setParameter("name", username);
        query.setParameter("email", email);
        List<User> results = query.getResultList();
        if (results != null && results.size() > 0) {
            return results.get(0);
        }
        return null;
    }

    /**
     * Register user
     *
     * @param username
     * @param password
     * @param email
     * @return
     * @throws Exception
     */
    public synchronized User registerUser(String username, String password, String email) throws Exception {
        if (checkUserExist(username, email) != null) {
            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"User already exist");
            throw new Exception("User already exist");
        }
        int id = generatedId("USER", 1);
        User user = new User(id, username, email, password, false);//not active account
        UserRoles userRole = em.find(UserRoles.class, IConstant.NORMAL_USER); //normal user
        user.setRoleId(userRole);
        em.persist(user);
        return user;
    }

    /**
     * method to activate registered users
     *
     * @param email
     * @return
     */
    public User activateUser(String email) {
        Query query = em.createNamedQuery("User.findByEmail");
        query.setParameter("email", email);
        List<User> results = query.getResultList();
        if (results != null && results.size() > 0) {
            User user = (User) results.get(0);
            user.setActive(true);
            em.persist(user);
            return user;
        }
        return null;
    }

    /**
     * load all question ratings
     *
     * @return
     */
    public QuestionRatingType[] loadAllRatings() {
        Query query = em.createNamedQuery("QuestionRatingType.findAll");
        List<QuestionRatingType> results = query.getResultList();
        if (results != null && results.size() > 0) {
            return (QuestionRatingType[]) results.toArray(new QuestionRatingType[0]);
        }
        return null;
    }

    /**
     * generate a primary key for a table
     *
     * @param key
     * @param size
     * @return
     */
    private synchronized int generatedId(String key, int size) {
        Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Generating keys for " + key + " with size=" + size);
        Autogen autogen = (Autogen) em.find(Autogen.class, key);
        int id = autogen.getTabValue();
        autogen.setTabValue(id + size);
        em.persist(autogen);
        return id;
    }

    /**
     * insert audit trail
     *
     * @param auditVO
     */
    public void createAuditTrail(AuditTrailVO auditVO) {
        AuditTrail newTrail = new AuditTrail();
        int id = generatedId("AUDIT", 1);
        newTrail.setId(id);
        newTrail.setReason(auditVO.getReason());
        newTrail.setActionId(auditVO.getActionId());
        newTrail.setUserId(auditVO.getUserId());
        newTrail.setDate(auditVO.getDate());
        Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Inserting audit trail for action id="+newTrail.getActionId());
        em.persist(newTrail);
    }

    /**
     * create new survey
     *
     * @param surveyVO
     * @param userId 
     * @return
     */
    public AuditTrailVO createNewSurvey(SurveyVO surveyVO, int userId) {
        if(getUserSurveyCount(userId)>=IConstant.MAX_USER_SURVEYS){
            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Exceed the max allowed surveys for this user "+userId);
            return null;
        }
        AuditTrailVO auditTrail = null;
        try {
            //generate insertion ids
            int id = generatedId("SURVEY", 1);
            int questionId = generatedId("QUESTION", surveyVO.getNoOfQuestions());
            int emailId = surveyVO.getSurveyEmails() != null ? generatedId("EMAIL", surveyVO.getSurveyEmails().length) : 0;
            //create new survey
            Survey survey = new Survey();
            survey.setId(id);
            survey.setTitle(surveyVO.getTitle());
            survey.setDescription(surveyVO.getDescription());
            survey.setNoOfQuestions(surveyVO.getNoOfQuestions());
            survey.setMaxParticipation(surveyVO.getMaxParticipation());
            survey.setOwnerId(surveyVO.getOwnerId());
            survey.setPrivateFlag(survey.getPrivateFlag());
            survey.setStatus(surveyVO.getStatus());
            em.persist(survey);
            em.flush();
            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Generated surveyId="+survey.getId()+"old survey Id="+id);
            id=survey.getId();
            for (QuestionVO surveryQuestion : surveyVO.getSurveryQuestions()) {
                Questions newQuestion = new Questions();
                newQuestion.setId(questionId);
                newQuestion.setQuestion(surveryQuestion.getQuestion());
                newQuestion.setBody(surveryQuestion.getBody());
                newQuestion.setRatingtypeId(surveryQuestion.getRatingtypeId());
                Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Inserting Question "+newQuestion.getQuestion());
                em.persist(newQuestion);
                em.flush();
                //associate survery to questions
                SurveyQuestions surveyMapQuestion = new SurveyQuestions(new SurveyQuestionsPK(id, questionId), surveryQuestion.getSequence());
                em.persist(surveyMapQuestion);
                questionId++;
            }
            //create survey emails
            if (surveyVO.getSurveyEmails() != null) {
                for (String surveyEmail : surveyVO.getSurveyEmails()) {
                    SurveyEmails newEmail = new SurveyEmails();
                    newEmail.setId(emailId);
                    newEmail.setSurveyId(id);
                    newEmail.setEmail(surveyEmail);
                    newEmail.setSubmitted(false);
                    Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Inserting survey email "+newEmail.getEmail());
                    em.persist(newEmail);
                    emailId++;
                }
                em.flush();
            }
            auditTrail = new AuditTrailVO();
            auditTrail.setActionId(IConstant.SURVEY_CREATED);
            auditTrail.setUserId(surveyVO.getOwnerId());
            auditTrail.setDate(new Date());
            auditTrail.setReason("" + id);
            return auditTrail;
        } catch (Exception ex) {
            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Error " + ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * get all user owned surveys If the user is the admin he can get the full
     * list but he can't activate/close/delete any survey
     *
     * @param userVO
     * @return
     */
    public Survey[] getMySurveyList(UserVO userVO) {
        Query query = null;
        if (userVO.getUserRole() == 2) {
            query = em.createNamedQuery("Survey.findByOwnerId");
            query.setParameter("ownerId", userVO.getId());
        } else {
            query = em.createNamedQuery("Survey.findAll");
        }
        List<Survey> results = query.getResultList();
        if (results != null && results.size() > 0) {
            return (Survey[]) results.toArray(new Survey[0]);
        }
        return null;
    }

    /**
     * get a status description
     *
     * @param statusId
     * @return
     */
    public String getStatusDesc(int statusId) {
        SurveyStatus status = em.find(SurveyStatus.class, statusId);
        if (status == null) {
            return "";
        }
        return status.getStatus();
    }

    /**
     * get current survey participation count
     *
     * @param surveyId
     * @return
     */
    public int getCurrentSurveyParticipation(int surveyId) {
        Query query = em.createNativeQuery("SELECT count(distinct user_id) FROM user_answers u,survey_questions q\n"
                + "where u.question_id=q.survey_question_id and q.survey_id=?");
        query.setParameter(1, surveyId);
        List<Long> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Current participants=" + results.get(0) + " for id=" + surveyId);
            return results.get(0).intValue();
        }
        return 0;
    }

    /**
     * activate survey by the owner
     *
     * @param surveryId
     * @param userId
     * @return
     */
    public boolean activateSurvey(int surveryId, int userId) {
        Query query = em.createNamedQuery("Survey.findByIdAndOwner");
        query.setParameter("id", surveryId);
        query.setParameter("ownerId", userId);
        List<Survey> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Survey survey = results.get(0);
            survey.setStatus(IConstant.ACTIVE_STATUS);
            return true;
        }
        return false;
    }

    /**
     * get survey mails
     *
     * @param surveryId
     * @return
     */
    public SurveyEmails[] getSurveyEmails(int surveryId) {
        Query query = em.createNamedQuery("SurveyEmails.findBySurveyId");
        query.setParameter("surveyId", surveryId);
        List<SurveyEmails> results = query.getResultList();
        if (results != null && results.size() > 0) {
            SurveyEmails[] emails = (SurveyEmails[]) results.toArray(new SurveyEmails[0]);
            return emails;
        }
        return null;
    }

    /**
     * close survey by the owner
     *
     * @param surveryId
     * @param userId
     * @return
     */
    public boolean closeSurvey(int surveryId, int userId) {
        Query query = em.createNamedQuery("Survey.findByIdAndOwner");
        query.setParameter("id", surveryId);
        query.setParameter("ownerId", userId);
        List<Survey> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Survey survey = results.get(0);
            survey.setStatus(IConstant.CLOSED_STATUS);
            return true;
        }
        return false;
    }

    /**
     * delete survey by the owner
     *
     * @param surveyId
     * @param userId
     * @return
     */
    public boolean deleteSurvey(int surveyId, int userId) {
        Query query = em.createNamedQuery("Survey.findByIdAndOwner");
        query.setParameter("id", surveyId);
        query.setParameter("ownerId", userId);
        List<Survey> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Survey survey = results.get(0);
            //delete survey
            em.remove(survey);
            query = em.createNamedQuery("SurveyEmails.findBySurveyId");
            query.setParameter("surveyId", surveyId);
            List<SurveyEmails> emailsResults = query.getResultList();
            if (emailsResults != null && emailsResults.size() > 0) {
                SurveyEmails[] emails = (SurveyEmails[]) emailsResults.toArray(new SurveyEmails[0]);
                for (SurveyEmails email : emails) {
                    //delete survey mails
                    em.remove(email);
                }
            }
            query = em.createNamedQuery("SurveyQuestions.findBySurveyId");
            query.setParameter("surveyId", surveyId);
            List<SurveyQuestions> questionResults = query.getResultList();
            if (questionResults != null && questionResults.size() > 0) {
                SurveyQuestions[] questions = (SurveyQuestions[]) questionResults.toArray(new SurveyQuestions[0]);
                for (SurveyQuestions currentSurveyQuestion : questions) {
                    Questions question = em.find(Questions.class, currentSurveyQuestion.getSurveyQuestionsPK().getSurveyQuestionId());
                    if (question != null) {
                        Query queryForAnswers = em.createNamedQuery("UserAnswers.findByQuestionId");
                        queryForAnswers.setParameter("questionId", question.getId());
                        List<UserAnswers> answersResults = queryForAnswers.getResultList();
                        if (answersResults != null && answersResults.size() > 0) {
                            Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"answersResults" + answersResults.size());
                            UserAnswers[] answers = (UserAnswers[]) answersResults.toArray(new UserAnswers[0]);
                            for (UserAnswers answer : answers) {
                                //delete user answers
                                em.remove(answer);
                            }
                        }
                        //delete question
                        em.remove(question);
                    }
                    //delete survery question relation
                    em.remove(currentSurveyQuestion);
                }
            }
            SurveyReports report = em.find(SurveyReports.class, surveyId);
            if (report != null) {
                //delete survey report
                em.remove(report);
            }
            return true;
        }
        return false;
    }

    /**
     * generate and get survey report
     *
     * @param surveryId
     * @return
     */
    public String getSurveyReport(int surveyId) {
        StringBuilder report = new StringBuilder("");
        Survey survey = em.find(Survey.class, surveyId);
        if (survey != null) {
            getCurrentSurveyParticipation(surveyId);
            report.append("<H1>Survey Title: ").append(survey.getTitle()).append("</H1>");
            report.append("<H2>Current participation: ").append(getCurrentSurveyParticipation(surveyId)).
                    append("/").append(survey.getMaxParticipation()).append("</H1><hr>");
            //load survey questions
            Questions[] surveyQuestions = getSurveyQuestionList(surveyId);
            int number=1;
            for (Questions current : surveyQuestions) {
                report.append("Question ").append(number).append(":").
                        append(current.getQuestion()).append("<br><ol>");
                //load question answers
                Query queryForAnswers = em.createNativeQuery("SELECT answer,count(answer) FROM user_answers u "
                        + "where question_id=? group by answer order by answer");
                queryForAnswers.setParameter(1, current.getId());
                List answersResults = queryForAnswers.getResultList();
                //if there are answers, let's group them
                if (answersResults != null && answersResults.size() > 0) {
                    Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"answersResults" + answersResults.size());
                    for(int i=0;i<answersResults.size();i++){
                        Object[] result = (Object[])answersResults.get(i);
                        report.append("<li>Answer=").append(mapAnswerToValue(""+result[0], current.getRatingtypeId())).
                                append(" count=").append(result[1]).append("</li>");
                    }
                }else{
                    report.append("<li>No answer(s)</li>");
                }
                report.append("</ol>");
                number++;
            }
            //save survey report
            createUpdateReport(surveyId, report);
            //update report status
            survey.setStatus(IConstant.REPORT_READY);
        }
        return report.toString();
    }
    /**
     * method to create/update survey report
     * @param surveyId
     * @param report 
     */
    private synchronized void createUpdateReport(int surveyId, StringBuilder report){
        Query reportQuery = em.createNamedQuery("SurveyReports.findBySurveyId");
        reportQuery.setParameter("surveyId", surveyId);
        List<SurveyReports> results = reportQuery.getResultList();
        if (results != null && results.size() > 0) {
            SurveyReports surveyReports=(SurveyReports)results.get(0);
            surveyReports.setReport(report.toString());
            surveyReports.setCreationDate(new Date());
        }else{
            int reportId=generatedId("REPORT", 1);
            SurveyReports newReport=new SurveyReports();
            newReport.setId(reportId);
            newReport.setSurveyId(surveyId);
            newReport.setReport(report.toString());
            newReport.setCreationDate(new Date());
            em.persist(newReport);
        }        
    }
    /**
     * method to map answer into type readable value
     * @param object
     * @param ratingtypeId
     * @return 
     */
    private String mapAnswerToValue(String inputValue, int ratingtypeId) {
        int value=Integer.parseInt(inputValue);
        switch(ratingtypeId){
            case 1:
            case 2:
                return inputValue;
            case 3:
                if(value==1){
                    return "Yes";
                } else{
                    return "No";
                }
            case 4:
                if(value==1){
                    return "True";
                } else{
                    return "False";
                }
            case 5:
                if(value==1){
                    return "Agree";
                } else{
                    return "Disagree";
                }                
            case 6:
                if(value==1){
                    return "Agree";
                } else if(value==2){
                    return "Neutral";
                } else{
                    return "Disagree";
                }                                
            case 7:
                if(value==1){
                    return "Totally Agree";
                } else if(value==2){
                    return "Agree";
                } else if(value==3){
                    return "Neutral";
                } else if(value==4){
                    return "Disagree";
                } else{
                    return "Totally Disagree";
                }                                
            case 8:
                if(value==1){
                    return "Excellent";
                } else if(value==2){
                    return "Good";
                } else if(value==3){
                    return "Fair";
                } else {
                    return "Bad";
                }                                
            default:
                return inputValue;
        }
    }

    /**
     * get all available survey list for participation for a user if active
     * survey with either - public - private but user mail is added in this
     * survey
     *
     * @param userVO
     * @return
     */
    public Survey[] getAvailableSurveyList(UserVO userVO) {
        //load only active surveys which is either public or the user email configured on it
        Query query = em.createNativeQuery("SELECT distinct s.id FROM survey s, survey_emails e "
                + "where s.status=2 and (private_flag=0 or (s.id=e.survey_id and e.email=?))");
        query.setParameter(1, userVO.getEmail());
        List<Long> results = query.getResultList();
        if (results != null && results.size() > 0) {
            List<Survey> surveyEligibleList = new ArrayList();
            for (int i = 0; i < results.size(); i++) {
                Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"Id=" + results.get(i));
                Survey survey = em.find(Survey.class, results.get(i).intValue());
                //only add it if not submitted before
                if (!checkSubmittedBefore(survey.getId(), userVO.getId())) {
                    surveyEligibleList.add(survey);
                }
            }
            if (surveyEligibleList.size() > 0) {
                Survey[] surveyList = (Survey[]) surveyEligibleList.toArray(new Survey[0]);
                return surveyList;
            }
        }
        return null;
    }

    /**
     * load all survey questions
     *
     * @param surveyId
     * @return
     */
    public Questions[] getSurveyQuestionList(int surveyId) {
        //load survey question ...
        Query query = em.createNativeQuery("SELECT id FROM survey_questions s, questions q "
                + "where s.survey_id=? and s.survey_question_id=q.id order by s.sequence");
        query.setParameter(1, surveyId);
        List<Long> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Questions[] questionList = new Questions[results.size()];
            for (int i = 0; i < results.size(); i++) {
                Questions question = em.find(Questions.class, results.get(i).intValue());
                questionList[i] = question;
            }
            return questionList;
        }
        return null;
    }

    /**
     * load survey details
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public Survey getSurveyDetails(UserVO userVO, int surveyId) {
        //should check if user eligible to load it or not
        //load only active surveys which is either public or the user email configured on it
        Query query = em.createNativeQuery("SELECT distinct s.id FROM survey s, survey_emails e "
                + "where s.status=2 and s.id=? and (private_flag=0 or (s.id=e.survey_id and e.email=?))");
        query.setParameter(1, surveyId);
        query.setParameter(2, userVO.getEmail());
        List<Long> results = query.getResultList();
        if (results != null && results.size() > 0) {
            Survey survey = em.find(Survey.class, results.get(0).intValue());
            return survey;
        }
        return null;
    }

    /**
     * submit survey answers for a user if - Not participated before for the
     * same survey - No of participants do not exceed max survey count
     *
     * @param userAnswerVOs
     * @param userId
     * @param surveyId
     * @return
     */
    public synchronized boolean submitSurveyAnswers(UserAnswerVO[] userAnswerVOs, int userId, int surveyId) {
        boolean canParticipate = checkSurveyParticipants(surveyId);
        boolean submittedBefore = checkSubmittedBefore(surveyId, userId);
        Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"canParticipate=" + canParticipate + " submiitedbefore=" + submittedBefore);
        if (canParticipate && !submittedBefore) {
            for (UserAnswerVO userAnser : userAnswerVOs) {
                UserAnswers newAnswer = new UserAnswers();
                newAnswer.setUserAnswersPK(new UserAnswersPK(userAnser.getQuestionId(), userId));
                newAnswer.setAnswer(userAnser.getAnswer());
                em.persist(newAnswer);
            }
            return true;
        }
        return false;
    }

    /**
     * check if survey participants less than the max configured value for
     * participants for this survey
     *
     * @param surveyId
     * @return
     */
    private boolean checkSurveyParticipants(int surveyId) {
        Survey survey = em.find(Survey.class, surveyId);
        if (survey != null && survey.getMaxParticipation() > getCurrentSurveyParticipation(surveyId)) {
            return true;
        }
        return false;
    }

    /**
     * check if same user already submitted answers for this survey before or
     * not
     *
     * @param surveyId
     * @param userId
     * @return
     */
    private boolean checkSubmittedBefore(int surveyId, int userId) {
        Query query = em.createNativeQuery("SELECT * FROM user_answers u, survey_questions q "
                + "where u.user_id=? and q.survey_id=? and u.question_id=q.survey_question_id;");
        query.setParameter(1, userId);
        query.setParameter(2, surveyId);
        List<Survey> results = query.getResultList();
        if (results != null && results.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * load notification template for action
     *
     * @param actionId
     * @return
     */
    public NotificationTemplate getNotificationForAction(int actionId) {
        NotificationTemplate template = em.find(NotificationTemplate.class, actionId);
        return template;
    }

    /**
     * load email configurations
     *
     * @return
     */
    public Configuration[] getEmailConfig() {
        Configuration[] configs = new Configuration[5];
        configs[0] = em.find(Configuration.class, IConstant.EMAIL_SERVER);
        configs[1] = em.find(Configuration.class, IConstant.EMAIL_SERVER_PORT);
        configs[2] = em.find(Configuration.class, IConstant.SSL);
        configs[3] = em.find(Configuration.class, IConstant.EMAIL_SERVER_USER);
        configs[4] = em.find(Configuration.class, IConstant.EMAIL_SERVER_PASSWORD);
        return configs;
    }

    /**
     * update mail configurations
     *
     * @param configVO
     * @return
     */
    public boolean setEmailConfig(ConfigurationVO[] configVO) {
        boolean updated = true;
        for (ConfigurationVO item : configVO) {
            Configuration config = em.find(Configuration.class, item.getConfigkey());
            config.setConfigValue(item.getConfigValue());
        }
        return updated;
    }
    /**
     * Method to get count of surveys owned by this user
     * @param userId
     * @return 
     */
    public synchronized int getUserSurveyCount(Integer userId) {
        //load only active surveys which is either public or the user email configured on it
        Query query = em.createNativeQuery("SELECT count(*) FROM survey s where owner_id=?");
        query.setParameter(1, userId);
        List<Long> results = query.getResultList();
        if (results != null && results.size() > 0) {
           Logger.getLogger(DAOHelper.class.getName()).log(Level.INFO,"count of user's surveys=" + results.get(0));
           return results.get(0).intValue();
        }
        return 0;
    }
}
