-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.44-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema survey
--

CREATE DATABASE IF NOT EXISTS survey;
USE survey;

--
-- Definition of table `action`
--

DROP TABLE IF EXISTS `action`;
CREATE TABLE `action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `action`
--

/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` (`id`,`action_name`) VALUES 
 (1,'Survey created'),
 (2,'survey updated'),
 (3,'survey activated'),
 (4,'survey closed'),
 (5,'survey deleted'),
 (6,'survey submitted'),
 (7,'survey report'),
 (8,'user login'),
 (9,'user registered'),
 (10,'user activated'),
 (11,'update mail configurations');
/*!40000 ALTER TABLE `action` ENABLE KEYS */;


--
-- Definition of table `audit_trail`
--

DROP TABLE IF EXISTS `audit_trail`;
CREATE TABLE `audit_trail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `reason` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_audit_trail_1` (`action_id`),
  KEY `FK_audit_trail_2` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `audit_trail`
--

/*!40000 ALTER TABLE `audit_trail` DISABLE KEYS */;
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (1,2,8,'2014-04-06 12:03:41','GUI login'),
 (42,2,1,'2014-03-24 18:43:27','Survey no#12'),
 (43,2,1,'2014-03-24 18:43:51','Survey no#13'),
 (44,2,8,'2014-03-24 18:44:57','GUI login'),
 (45,2,1,'2014-03-24 18:45:15','Survey no#14'),
 (46,2,8,'2014-03-24 18:46:37','GUI login'),
 (47,2,3,'2014-03-24 18:46:43','Activate survey 12'),
 (48,2,3,'2014-03-24 18:46:44','Activate survey 14'),
 (49,2,8,'2014-03-24 19:58:02','GUI login'),
 (50,2,8,'2014-03-24 20:01:58','GUI login'),
 (51,2,8,'2014-03-24 20:17:34','GUI login'),
 (52,2,8,'2014-03-24 20:25:29','GUI login'),
 (53,2,8,'2014-03-24 20:27:00','GUI login'),
 (54,2,1,'2014-03-24 20:29:53','Survey no#15'),
 (55,2,8,'2014-03-24 20:31:07','GUI login'),
 (56,2,3,'2014-03-24 20:31:11','Activate survey 15'),
 (57,2,4,'2014-03-24 20:31:13','Closed survey 15'),
 (58,2,3,'2014-03-24 20:31:14','Activate survey 15'),
 (59,2,8,'2014-03-24 20:55:10','GUI login'),
 (60,2,8,'2014-03-24 22:02:36','GUI login'),
 (61,2,8,'2014-03-24 22:07:51','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (62,2,4,'2014-03-24 22:07:59','Survey closed :12'),
 (63,2,3,'2014-03-24 22:08:01','Survey Activated :12'),
 (64,2,8,'2014-03-24 22:10:48','GUI login'),
 (65,2,8,'2014-03-24 22:11:39','GUI login'),
 (66,2,6,'2014-03-24 22:11:47','Survey submitted :12'),
 (67,2,8,'2014-03-24 22:12:52','GUI login'),
 (68,2,6,'2014-03-24 22:13:02','Survey submitted :12'),
 (69,2,6,'2014-03-24 22:15:24','Survey submitted :15'),
 (70,2,6,'2014-03-24 22:16:37','Survey submitted :14'),
 (71,2,3,'2014-03-24 22:18:08','Survey Activated :13'),
 (72,2,6,'2014-03-24 22:18:24','Survey submitted :13'),
 (73,2,4,'2014-03-24 22:24:39','Survey closed :14'),
 (74,2,8,'2014-03-24 22:27:30','GUI login'),
 (75,2,6,'2014-03-24 22:29:20','Survey submitted :13'),
 (76,2,8,'2014-03-25 07:27:27','GUI login'),
 (77,2,3,'2014-03-25 07:28:24','Survey Activated :12'),
 (78,2,8,'2014-03-25 07:32:00','GUI login'),
 (79,2,3,'2014-03-25 07:32:05','Survey Activated :12'),
 (80,2,8,'2014-03-25 07:33:19','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (81,2,3,'2014-03-25 07:33:23','Survey Activated :12'),
 (82,2,8,'2014-03-25 07:34:18','GUI login'),
 (83,2,3,'2014-03-25 07:34:22','Survey Activated :12'),
 (84,3,9,'2014-03-25 14:19:21','User registered'),
 (85,3,8,'2014-03-25 14:31:05','GUI login'),
 (86,3,1,'2014-03-25 14:31:52','Survey no#16'),
 (87,3,3,'2014-03-25 14:32:04','Survey Activated :16'),
 (88,4,9,'2014-03-25 15:31:16','User registered'),
 (89,4,8,'2014-03-25 15:31:34','GUI login'),
 (90,4,10,'2014-03-25 17:25:46','User activated'),
 (91,4,8,'2014-03-25 17:27:02','GUI login'),
 (92,4,10,'2014-03-25 17:39:28','User activated'),
 (93,4,10,'2014-03-25 17:40:47','User activated'),
 (94,4,10,'2014-03-25 17:41:42','User activated'),
 (95,5,9,'2014-03-25 17:43:34','User registered'),
 (96,5,10,'2014-03-25 17:43:54','User activated'),
 (97,5,8,'2014-03-25 17:44:05','GUI login'),
 (98,5,1,'2014-03-25 17:44:42','Survey no#17'),
 (99,2,8,'2014-03-25 17:44:58','GUI login'),
 (100,2,8,'2014-03-25 17:46:43','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (101,5,8,'2014-03-25 17:48:43','GUI login'),
 (102,5,3,'2014-03-25 17:48:48','Survey Activated :17'),
 (103,5,4,'2014-03-25 17:51:09','Survey closed :17'),
 (104,5,3,'2014-03-25 17:51:12','Survey Activated :17'),
 (105,5,8,'2014-03-25 17:52:28','GUI login'),
 (106,5,3,'2014-03-25 17:52:31','Survey Activated :17'),
 (107,5,4,'2014-03-25 17:52:58','Survey closed :17'),
 (108,5,3,'2014-03-25 17:53:07','Survey Activated :17'),
 (109,5,8,'2014-03-25 17:54:21','GUI login'),
 (110,5,4,'2014-03-25 17:54:24','Survey closed :17'),
 (111,5,3,'2014-03-25 17:54:25','Survey Activated :17'),
 (112,6,9,'2014-03-25 19:10:07','User registered'),
 (113,7,9,'2014-03-25 19:11:26','User registered'),
 (114,8,9,'2014-03-25 19:13:18','User registered'),
 (115,9,9,'2014-03-25 19:14:19','User registered'),
 (116,10,9,'2014-03-25 19:16:46','User registered'),
 (117,11,9,'2014-03-25 19:17:41','User registered'),
 (118,12,9,'2014-03-25 19:19:21','User registered'),
 (119,13,9,'2014-03-25 19:21:18','User registered');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (120,14,9,'2014-03-25 19:23:07','User registered'),
 (121,15,9,'2014-03-25 19:23:50','User registered'),
 (122,16,9,'2014-03-25 19:24:39','User registered'),
 (123,17,9,'2014-03-25 19:26:16','User registered'),
 (124,18,9,'2014-03-25 19:27:42','User registered'),
 (125,19,9,'2014-03-25 19:28:56','User registered'),
 (126,20,9,'2014-03-25 19:30:03','User registered'),
 (127,21,9,'2014-03-25 19:32:30','User registered'),
 (128,22,9,'2014-03-25 19:33:15','User registered'),
 (129,23,9,'2014-03-25 19:34:54','User registered'),
 (130,24,9,'2014-03-25 19:35:55','User registered'),
 (131,25,9,'2014-03-25 19:40:28','User registered'),
 (132,25,10,'2014-03-25 19:41:27','User activated'),
 (133,5,8,'2014-03-25 19:43:26','GUI login'),
 (134,5,4,'2014-03-25 19:43:32','Survey closed :17'),
 (135,5,3,'2014-03-25 19:43:33','Survey Activated :17'),
 (136,2,8,'2014-03-25 21:07:34','GUI login'),
 (137,2,4,'2014-03-25 21:08:25','Survey closed :12'),
 (138,2,3,'2014-03-25 21:08:28','Survey Activated :12');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (139,2,3,'2014-03-25 21:10:02','Survey Activated :12'),
 (140,2,4,'2014-03-25 21:10:08','Survey closed :13'),
 (141,2,3,'2014-03-25 21:10:11','Survey Activated :13'),
 (142,2,8,'2014-03-25 21:24:06','GUI login'),
 (143,2,8,'2014-03-25 21:24:15','GUI login'),
 (144,5,8,'2014-03-25 21:24:23','GUI login'),
 (145,2,8,'2014-03-25 21:24:33','GUI login'),
 (146,1,8,'2014-03-25 21:24:44','GUI login'),
 (147,2,8,'2014-03-25 22:08:21','GUI login'),
 (148,1,8,'2014-03-25 22:09:38','GUI login'),
 (149,2,8,'2014-03-25 22:12:37','GUI login'),
 (150,2,3,'2014-03-25 22:12:41','Survey Activated :14'),
 (151,2,4,'2014-03-25 22:12:43','Survey closed :14'),
 (152,1,8,'2014-03-25 22:13:13','GUI login'),
 (153,2,8,'2014-03-25 22:14:22','GUI login'),
 (154,5,8,'2014-03-25 22:14:34','GUI login'),
 (155,5,4,'2014-03-25 22:14:38','Survey closed :17'),
 (156,5,3,'2014-03-25 22:14:40','Survey Activated :17'),
 (157,2,8,'2014-03-25 22:14:48','GUI login'),
 (158,2,8,'2014-03-26 21:14:21','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (159,1,8,'2014-03-26 21:14:55','GUI login'),
 (160,1,10,'2014-03-26 21:17:34','Update email configurations'),
 (161,2,8,'2014-03-26 21:18:58','GUI login'),
 (162,5,8,'2014-03-26 21:19:32','GUI login'),
 (163,5,4,'2014-03-26 21:19:36','Survey closed :17'),
 (164,5,3,'2014-03-26 21:19:39','Survey Activated :17'),
 (165,5,8,'2014-03-26 21:20:44','GUI login'),
 (166,5,4,'2014-03-26 21:20:47','Survey closed :17'),
 (167,5,3,'2014-03-26 21:20:48','Survey Activated :17'),
 (168,2,8,'2014-03-26 23:03:15','GUI login'),
 (169,2,8,'2014-03-26 23:17:58','GUI login'),
 (170,2,7,'2014-03-26 23:18:03','Report generated for survey 14'),
 (171,5,8,'2014-03-26 23:18:51','GUI login'),
 (172,2,8,'2014-03-26 23:19:12','GUI login'),
 (173,2,4,'2014-03-26 23:19:19','Survey closed :13'),
 (174,2,8,'2014-03-26 23:21:13','GUI login'),
 (175,2,7,'2014-03-26 23:22:00','Report generated for survey 13'),
 (176,2,7,'2014-03-26 23:23:00','Report generated for survey 13'),
 (177,2,8,'2014-03-26 23:24:03','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (178,2,7,'2014-03-26 23:24:07','Report generated for survey 13'),
 (179,2,8,'2014-04-06 10:01:35','GUI login'),
 (180,2,8,'2014-04-06 10:34:32','GUI login'),
 (181,2,8,'2014-04-06 10:40:54','GUI login'),
 (182,2,8,'2014-04-06 10:41:55','GUI login'),
 (183,2,8,'2014-04-06 10:42:16','GUI login'),
 (184,2,7,'2014-04-06 10:42:16','Report generated for survey 13'),
 (185,2,8,'2014-04-06 10:42:30','GUI login'),
 (186,2,7,'2014-04-06 10:42:30','Report generated for survey 13'),
 (187,2,8,'2014-04-06 10:42:32','GUI login'),
 (188,2,7,'2014-04-06 10:42:32','Report generated for survey 13'),
 (189,5,8,'2014-04-06 10:42:45','GUI login'),
 (190,5,8,'2014-04-06 10:43:14','GUI login'),
 (191,5,8,'2014-04-06 10:45:02','GUI login'),
 (192,2,8,'2014-04-06 10:45:16','GUI login'),
 (193,2,8,'2014-04-06 10:46:08','GUI login'),
 (194,2,7,'2014-04-06 10:46:08','Report generated for survey 13'),
 (195,2,8,'2014-04-06 10:46:11','GUI login'),
 (196,2,8,'2014-04-06 10:46:53','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (197,5,8,'2014-04-06 10:47:22','GUI login'),
 (198,2,8,'2014-04-06 10:47:33','GUI login'),
 (199,2,8,'2014-04-06 10:47:39','GUI login'),
 (200,2,8,'2014-04-06 11:01:06','GUI login'),
 (201,2,5,'2014-04-06 11:01:11','Survey deleted :12'),
 (202,2,5,'2014-04-06 11:01:18','Survey deleted :13'),
 (203,2,5,'2014-04-06 11:01:19','Survey deleted :14'),
 (204,2,5,'2014-04-06 11:01:21','Survey deleted :15'),
 (205,5,8,'2014-04-06 11:01:33','GUI login'),
 (206,5,5,'2014-04-06 11:01:37','Survey deleted :17'),
 (207,1,8,'2014-04-06 11:01:47','GUI login'),
 (208,2,8,'2014-04-06 11:03:00','GUI login'),
 (209,5,8,'2014-04-06 11:05:12','GUI login'),
 (210,1,8,'2014-04-06 11:05:38','GUI login'),
 (211,3,8,'2014-04-06 11:05:58','GUI login'),
 (212,3,5,'2014-04-06 11:06:01','Survey deleted :16'),
 (213,2,8,'2014-04-06 11:06:40','GUI login'),
 (214,1,8,'2014-04-06 11:06:48','GUI login'),
 (215,1,8,'2014-04-06 11:15:15','GUI login'),
 (216,1,1,'2014-04-06 11:26:45','Survey no#1');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (217,2,8,'2014-04-06 11:33:17','GUI login'),
 (218,5,8,'2014-04-06 11:33:47','GUI login'),
 (219,1,8,'2014-04-06 11:35:00','GUI login'),
 (220,1,3,'2014-04-06 11:35:03','Survey Activated :18'),
 (221,2,8,'2014-04-06 11:35:35','GUI login'),
 (222,2,8,'2014-04-06 11:46:56','GUI login'),
 (223,2,8,'2014-04-06 11:52:11','GUI login'),
 (224,2,8,'2014-04-06 11:55:24','GUI login'),
 (225,2,6,'2014-04-06 12:07:57','Survey submitted :18'),
 (226,2,1,'2014-04-06 12:08:39','Survey no#19'),
 (227,2,3,'2014-04-06 12:09:45','Survey Activated :19'),
 (228,2,4,'2014-04-06 12:09:47','Survey closed :19'),
 (229,2,3,'2014-04-06 12:09:48','Survey Activated :19'),
 (230,2,6,'2014-04-06 12:09:58','Survey submitted :19'),
 (231,5,8,'2014-04-06 12:10:11','GUI login'),
 (232,5,1,'2014-04-06 12:10:57','Survey no#20'),
 (233,5,3,'2014-04-06 12:11:07','Survey Activated :20'),
 (234,5,6,'2014-04-06 12:11:28','Survey submitted :20'),
 (235,5,6,'2014-04-06 12:12:27','Survey submitted :18'),
 (236,1,8,'2014-04-06 12:12:40','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (237,1,4,'2014-04-06 12:13:27','Survey closed :18'),
 (238,1,7,'2014-04-06 12:13:30','Report generated for survey 18'),
 (239,1,3,'2014-04-06 12:14:06','Survey Activated :18'),
 (240,1,3,'2014-04-06 12:14:07','Survey Activated :18'),
 (241,5,8,'2014-04-06 12:16:05','GUI login'),
 (242,26,9,'2014-04-06 12:17:02','User registered'),
 (243,2,8,'2014-04-06 12:18:07','GUI login'),
 (244,2,1,'2014-04-06 12:18:43','Survey no#21'),
 (245,1,8,'2014-04-06 12:19:03','GUI login'),
 (246,3,8,'2014-04-06 13:50:58','GUI login'),
 (247,2,8,'2014-04-06 20:57:14','GUI login'),
 (248,5,8,'2014-04-06 20:57:49','GUI login'),
 (249,2,8,'2014-04-06 21:10:25','GUI login'),
 (250,5,8,'2014-04-06 21:10:38','GUI login'),
 (251,5,8,'2014-04-06 21:11:34','GUI login'),
 (252,5,7,'2014-04-06 21:11:34','Report generated for survey 18'),
 (253,5,8,'2014-04-06 21:15:07','GUI login'),
 (254,5,7,'2014-04-06 21:15:07','Report generated for survey 18'),
 (255,5,8,'2014-04-06 21:15:33','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (256,5,7,'2014-04-06 21:15:34','Report generated for survey 18'),
 (257,2,8,'2014-04-06 21:43:15','GUI login'),
 (258,3,8,'2014-04-07 16:31:50','GUI login'),
 (259,4,8,'2014-04-07 16:32:25','GUI login'),
 (260,1,8,'2014-04-07 16:32:47','GUI login'),
 (261,4,8,'2014-04-07 16:36:04','GUI login'),
 (262,2,8,'2014-04-07 20:13:42','GUI login'),
 (263,2,3,'2014-04-07 20:13:48','Survey Activated :21'),
 (264,2,4,'2014-04-07 20:13:53','Survey closed :21'),
 (265,2,3,'2014-04-07 20:13:56','Survey Activated :21'),
 (266,2,4,'2014-04-07 20:13:58','Survey closed :21'),
 (267,2,7,'2014-04-07 20:14:03','Report generated for survey 21'),
 (268,2,5,'2014-04-07 20:14:12','Survey deleted :21'),
 (269,2,5,'2014-04-07 20:14:20','Survey deleted :19'),
 (270,2,1,'2014-04-07 20:14:50','Survey no#22'),
 (271,2,6,'2014-04-07 20:15:19','Survey submitted :20'),
 (272,2,3,'2014-04-07 20:15:48','Survey Activated :22'),
 (273,2,8,'2014-04-07 20:20:36','GUI login'),
 (274,2,5,'2014-04-07 20:20:41','Survey deleted :22');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (275,2,1,'2014-04-07 20:21:03','Survey no#23'),
 (276,2,3,'2014-04-07 20:21:08','Survey Activated :23'),
 (277,2,6,'2014-04-07 20:21:49','Survey submitted :23'),
 (278,2,4,'2014-04-07 20:21:55','Survey closed :23'),
 (279,2,3,'2014-04-07 20:21:57','Survey Activated :23'),
 (280,2,8,'2014-04-07 20:38:59','GUI login'),
 (281,2,8,'2014-04-07 22:28:57','GUI login'),
 (282,5,8,'2014-04-07 22:34:00','GUI login'),
 (283,5,1,'2014-04-07 22:37:24','Survey no#24'),
 (284,5,4,'2014-04-07 22:38:38','Survey closed :20'),
 (285,5,3,'2014-04-07 22:38:39','Survey Activated :20'),
 (286,5,3,'2014-04-07 22:38:42','Survey Activated :24'),
 (287,5,4,'2014-04-07 22:38:46','Survey closed :24'),
 (288,5,4,'2014-04-07 22:38:47','Survey closed :20'),
 (289,5,3,'2014-04-07 22:38:49','Survey Activated :20'),
 (290,5,3,'2014-04-07 22:38:50','Survey Activated :24'),
 (291,2,8,'2014-04-07 22:42:59','GUI login'),
 (292,2,1,'2014-04-07 22:43:09','Survey no#25'),
 (293,2,8,'2014-04-07 22:47:31','GUI login');
INSERT INTO `audit_trail` (`id`,`user_id`,`action_id`,`date`,`reason`) VALUES 
 (294,2,8,'2014-04-07 22:49:24','GUI login'),
 (295,2,1,'2014-04-07 22:49:37','Survey no#26');
/*!40000 ALTER TABLE `audit_trail` ENABLE KEYS */;


--
-- Definition of table `autogen`
--

DROP TABLE IF EXISTS `autogen`;
CREATE TABLE `autogen` (
  `tab_key` varchar(20) NOT NULL,
  `tab_value` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tab_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autogen`
--

/*!40000 ALTER TABLE `autogen` DISABLE KEYS */;
INSERT INTO `autogen` (`tab_key`,`tab_value`) VALUES 
 ('AUDIT',297),
 ('EMAIL',55),
 ('QUESTION',149),
 ('REPORT',5),
 ('SURVEY',27),
 ('USER',27);
/*!40000 ALTER TABLE `autogen` ENABLE KEYS */;


--
-- Definition of table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
CREATE TABLE `configuration` (
  `Config_key` varchar(30) NOT NULL,
  `config_value` varchar(80) NOT NULL,
  PRIMARY KEY (`Config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `configuration`
--

/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`Config_key`,`config_value`) VALUES 
 ('EMAIL_SERVER','smtp.gmail.com'),
 ('EMAIL_SERVER_PASSWORD','my_password'),
 ('EMAIL_SERVER_PORT','465'),
 ('EMAIL_SERVER_USER','user@gmail.com!!'),
 ('SSL','true');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;


--
-- Definition of table `notification_template`
--

DROP TABLE IF EXISTS `notification_template`;
CREATE TABLE `notification_template` (
  `action_id` int(10) unsigned NOT NULL,
  `subject` varchar(60) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notification_template`
--

/*!40000 ALTER TABLE `notification_template` DISABLE KEYS */;
INSERT INTO `notification_template` (`action_id`,`subject`,`body`) VALUES 
 (1,'Survey Created Successfully','Dear %0,<br>You have successfully created your new survey with id = %1 in SurveyOne<br><br>.<br><br>Best Regards,<br>SurveyOne<br>'),
 (3,'Survey Invitation','Dear,<br>You are requested by %0 to participate in the following survey:<br> * Survey Id=%1<br>Best Regards,<br>SurveyOne<br>'),
 (9,'SurveyOne Registration Confirmation','Dear %0<br>You have successfully registered in SurveyOne<br>To activate your account click on the following <a href=\'%1\'>link</a>.<br><br>Best Regards,<br>SurveyOne<br>'),
 (10,'SurveyOne Account Activation Confirmation','Dear %0,<br>You have successfully activated your account in SurveyOne<br><br>You can login to our system by click on the following <a href=\'%1\'>link</a>.<br><br>Best Regards,<br>SurveyOne<br>');
/*!40000 ALTER TABLE `notification_template` ENABLE KEYS */;


--
-- Definition of table `question_rating_type`
--

DROP TABLE IF EXISTS `question_rating_type`;
CREATE TABLE `question_rating_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_rating_type`
--

/*!40000 ALTER TABLE `question_rating_type` DISABLE KEYS */;
INSERT INTO `question_rating_type` (`id`,`type`,`description`) VALUES 
 (1,'Rate 1 to 5','Rating from 1 to 5 (1, 2, 3, 4, 5)'),
 (2,'Rate 1 to 10','Rating from 1 to 10 (1,2,3,4,5,6,7,8,9,10)'),
 (3,'Yes/No','Yes or No'),
 (4,'True/False','2 value true or false'),
 (5,'Agree/Disagree','2 values agree or disagree'),
 (6,'Agree/Disagree (3)','3 values agree, neutral , disagree'),
 (7,'Agree/Disagree (5)','5 values totally agree, agree, neutral , disagree, totally disagree'),
 (8,'Excellent/Bad (4)','4 values excellent, good, fair, bad');
/*!40000 ALTER TABLE `question_rating_type` ENABLE KEYS */;


--
-- Definition of table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(300) NOT NULL,
  `rating_type_Id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_questions_1` (`rating_type_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` (`id`,`question`,`rating_type_Id`,`body`) VALUES 
 (77,'Are you working in performance tuning?',3,'Is your current job related to performance tuning ?'),
 (78,'The book change your view?',7,'Regarding performance tuning, does this book changed your view ?'),
 (79,'Do you like the chapter sequence?',4,'Do you feel the book chapters are well organized?'),
 (80,'Do you like book examples?',3,'Is book examples are good?'),
 (81,'How do you rate 1st chapter?',1,'Rating of chapter 1 from 1 to 5.'),
 (82,'How do you rate 2nd chapter?',1,'Rating of chapter 2 from 1 to 5.'),
 (83,'How do you rate 3rd chapter?',1,'Rating of chapter 3 from 1 to 5.'),
 (84,'How do you rate 4th chapter?',1,'Rating of chapter 4 from 1 to 5.'),
 (85,'How do you rate 5th chapter?',1,'Rating of chapter 5 from 1 to 5.'),
 (86,'How do you rate 6th chapter?',1,'Rating of chapter 6 from 1 to 5.'),
 (87,'How do you rate 7th chapter?',1,'Rating of chapter 7 from 1 to 5.'),
 (88,'How do you rate 8th chapter?',1,'Rating of chapter 8 from 1 to 5.'),
 (89,'How do you rate 9th chapter?',1,'Rating of chapter 9 from 1 to 5.');
INSERT INTO `questions` (`id`,`question`,`rating_type_Id`,`body`) VALUES 
 (90,'How do you rate 10th chapter?',1,'Rating of chapter 10 from 1 to 5.'),
 (91,'How do you rate 11th chapter?',1,'Rating of chapter 11 from 1 to 5.'),
 (92,'How do you rate 12th chapter?',1,'Rating of chapter 12 from 1 to 5.'),
 (93,'Will you recommend this book?',3,'Are you going to recommend this book ?'),
 (94,'Is their any gaps in the book?',6,'Do you see any missing items in the book ?'),
 (95,'Is the book covers performance tools?',8,'Do you see the book covered performance diagnostic tools very well ?'),
 (96,'How do you rate the book?',2,'Book overall rating from 1 to 10.'),
 (109,'question_3',3,'body_3'),
 (110,'question_7',7,'body_7'),
 (111,'question_6',6,'body_6'),
 (112,'question_5',5,'body_5'),
 (113,'question_2',2,'body_2'),
 (114,'question_4',4,'body_4'),
 (115,'question_1',1,'body_1'),
 (132,'question_1',1,'body_1'),
 (133,'question_2',1,'body_2'),
 (134,'question_3',1,'body_3'),
 (135,'question_4',1,'body_4'),
 (136,'question_5',1,'body_5');
INSERT INTO `questions` (`id`,`question`,`rating_type_Id`,`body`) VALUES 
 (137,'question_6',1,'body_6'),
 (138,'question_7',1,'body_7'),
 (139,'question_8',1,'body_8'),
 (140,'question_9',1,'body_9'),
 (141,'question_1',1,'body_1'),
 (142,'question_2',1,'body_2'),
 (143,'question_3',1,'body_3'),
 (144,'question_1',1,'body_1'),
 (145,'question_2',1,'body_2'),
 (146,'question_1',1,'body_1'),
 (147,'question_2',1,'body_2'),
 (148,'question_3',1,'body_3');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;


--
-- Definition of table `survey`
--

DROP TABLE IF EXISTS `survey`;
CREATE TABLE `survey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `owner_id` int(10) unsigned NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `private_flag` tinyint(1) NOT NULL,
  `max_participation` int(10) unsigned NOT NULL,
  `description` text,
  `no_of_questions` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `survey`
--

/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` (`id`,`title`,`owner_id`,`status`,`private_flag`,`max_participation`,`description`,`no_of_questions`) VALUES 
 (18,'Book user\'s survey',1,2,0,100,'This survey to get the user\'s feedback about the book; Java Enterprise Edition 7 Performance Tuning',20),
 (20,'private survey',5,2,0,20,'',7),
 (23,'Test survey',2,2,0,100,'test',9),
 (24,'survery title',5,2,0,100,'',3),
 (25,'survery title',2,1,0,100,'',2),
 (26,'survery title',2,1,0,100,'',3);
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;


--
-- Definition of table `survey_emails`
--

DROP TABLE IF EXISTS `survey_emails`;
CREATE TABLE `survey_emails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `survey_id` int(10) unsigned NOT NULL DEFAULT '0',
  `submitted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `survey_emails`
--

/*!40000 ALTER TABLE `survey_emails` DISABLE KEYS */;
INSERT INTO `survey_emails` (`id`,`email`,`survey_id`,`submitted`) VALUES 
 (36,'osama.oransa@surveyOne.com',18,0),
 (37,' osama@surveryOne.com',18,0),
 (40,'osama.oransa@surveyOne.com',20,0),
 (41,' osama@surveryOne.com',20,0),
 (47,' osama@surveryOne.com',23,0),
 (48,'osama.oransa@surveyOne.com',23,0),
 (49,' osama@surveryOne.com',24,0),
 (50,'osama.oransa@surveyOne.com',24,0),
 (51,' osama@surveryOne.com',25,0),
 (52,'osama.oransa@surveyOne.com',25,0),
 (53,'osama.oransa@surveyOne.com',26,0),
 (54,' osama@surveryOne.com',26,0);
/*!40000 ALTER TABLE `survey_emails` ENABLE KEYS */;


--
-- Definition of table `survey_questions`
--

DROP TABLE IF EXISTS `survey_questions`;
CREATE TABLE `survey_questions` (
  `survey_id` int(10) unsigned NOT NULL DEFAULT '0',
  `survey_question_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sequence` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`survey_id`,`survey_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `survey_questions`
--

/*!40000 ALTER TABLE `survey_questions` DISABLE KEYS */;
INSERT INTO `survey_questions` (`survey_id`,`survey_question_id`,`sequence`) VALUES 
 (18,77,0),
 (18,78,1),
 (18,79,2),
 (18,80,3),
 (18,81,4),
 (18,82,5),
 (18,83,6),
 (18,84,7),
 (18,85,8),
 (18,86,9),
 (18,87,10),
 (18,88,11),
 (18,89,12),
 (18,90,13),
 (18,91,14),
 (18,92,15),
 (18,93,16),
 (18,94,17),
 (18,95,18),
 (18,96,19),
 (20,109,0),
 (20,110,1),
 (20,111,2),
 (20,112,3),
 (20,113,4),
 (20,114,5),
 (20,115,6),
 (23,132,1),
 (23,133,2),
 (23,134,3),
 (23,135,4),
 (23,136,5),
 (23,137,6),
 (23,138,7),
 (23,139,8),
 (23,140,9),
 (24,141,1),
 (24,142,2),
 (24,143,3),
 (25,144,1),
 (25,145,2),
 (26,146,1),
 (26,147,2),
 (26,148,3);
/*!40000 ALTER TABLE `survey_questions` ENABLE KEYS */;


--
-- Definition of table `survey_reports`
--

DROP TABLE IF EXISTS `survey_reports`;
CREATE TABLE `survey_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` int(10) unsigned NOT NULL,
  `report` text NOT NULL,
  `creation_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_survey_reports_1` (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `survey_reports`
--

/*!40000 ALTER TABLE `survey_reports` DISABLE KEYS */;
INSERT INTO `survey_reports` (`id`,`survey_id`,`report`,`creation_date`) VALUES 
 (1,18,'<H1>Survey Title: Book user\'s survey</H1><H2>Current participation: 2/100</H1><hr>Question 1:Do you like the chapter sequence?<br><ol><li>Answer=True count=2</li></ol>Question 2:How do you rate 4th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 3:Are you working in performance tuning?<br><ol><li>Answer=Yes count=2</li></ol>Question 4:Do you like book examples?<br><ol><li>Answer=Yes count=2</li></ol>Question 5:How do you rate 10th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=4 count=1</li></ol>Question 6:How do you rate 12th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 7:How do you rate 3rd chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=4 count=1</li></ol>Question 8:How do you rate 7th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 9:How do you rate 6th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=4 count=1</li></ol>Question 10:How do you rate 1st chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 11:How do you rate 8th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=4 count=1</li></ol>Question 12:How do you rate 5th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 13:The book change your view?<br><ol><li>Answer=Totally Agree count=1</li><li>Answer=Agree count=1</li></ol>Question 14:Is their any gaps in the book?<br><ol><li>Answer=Agree count=1</li><li>Answer=Neutral count=1</li></ol>Question 15:Will you recommend this book?<br><ol><li>Answer=Yes count=2</li></ol>Question 16:How do you rate 2nd chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 17:How do you rate 11th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=4 count=1</li></ol>Question 18:How do you rate 9th chapter?<br><ol><li>Answer=1 count=1</li><li>Answer=5 count=1</li></ol>Question 19:Is the book covers performance tools?<br><ol><li>Answer=Agree count=2</li></ol>Question 20:How do you rate the book?<br><ol><li>Answer=1 count=1</li><li>Answer=9 count=1</li></ol>','2014-04-06 21:15:34'),
 (2,21,'<H1>Survey Title: test survey</H1><H2>Current participation: 0/30</H1><hr>Question 1:question_2<br><ol><li>No answer(s)</li></ol>Question 2:question_3<br><ol><li>No answer(s)</li></ol>Question 3:question_4<br><ol><li>No answer(s)</li></ol>Question 4:question_1<br><ol><li>No answer(s)</li></ol>','2014-04-07 20:14:03');
/*!40000 ALTER TABLE `survey_reports` ENABLE KEYS */;


--
-- Definition of table `survey_status`
--

DROP TABLE IF EXISTS `survey_status`;
CREATE TABLE `survey_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `survey_status`
--

/*!40000 ALTER TABLE `survey_status` DISABLE KEYS */;
INSERT INTO `survey_status` (`id`,`status`) VALUES 
 (1,'Created'),
 (2,'Active'),
 (3,'Closed'),
 (4,'Report ready');
/*!40000 ALTER TABLE `survey_status` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `roleId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_1` (`roleId`),
  CONSTRAINT `FK_user_1` FOREIGN KEY (`roleId`) REFERENCES `user_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`name`,`email`,`password`,`active`,`roleId`) VALUES 
 (1,'admin','admin@survey.com','admin',1,1),
 (2,'user','user@survey.com','user',1,2),
 (3,'osama','osama@surveyOne.com','osama',1,2),
 (4,'osama2','osama2@surveyOne.com','osama2',1,2),
 (5,'osa','osa@surveyOne.com','osa',1,2),
 (6,'test','test@surveyOne.com','test',0,2),
 (7,'user1','osa@surveyOne.com','user1',1,2),
 (8,'user2','osa@surveyOne.com','user2',1,2),
 (9,'user3','osa@surveyOne.com','user3',1,2),
 (10,'user4','osa@surveyOne.com','user4',1,2),
 (11,'user5','osa@surveyOne.com','user5',1,2),
 (12,'user6','osa@surveyOne.com','user6',1,2),
 (13,'user7','osa@surveyOne.com','user7',1,2),
 (14,'user8','osa@surveyOne.com','user8',1,2),
 (15,'user9','osa@surveyOne.com','user9',1,2),
 (16,'user10','osa@surveyOne.com','user10',1,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `user_answers`
--

DROP TABLE IF EXISTS `user_answers`;
CREATE TABLE `user_answers` (
  `question_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `answer` int(10) unsigned NOT NULL,
  PRIMARY KEY (`question_id`,`user_id`),
  KEY `FK_question_use_answer_1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_answers`
--

/*!40000 ALTER TABLE `user_answers` DISABLE KEYS */;
INSERT INTO `user_answers` (`question_id`,`user_id`,`answer`) VALUES 
 (77,2,1),
 (77,5,1),
 (78,2,1),
 (78,5,5),
 (79,2,1),
 (79,5,1),
 (80,2,1),
 (80,5,1),
 (81,2,1),
 (81,5,4),
 (82,2,1),
 (82,5,5),
 (83,2,1),
 (83,5,4),
 (84,2,1),
 (84,5,5),
 (85,2,1),
 (85,5,4),
 (86,2,1),
 (86,5,5),
 (87,2,1),
 (87,5,4),
 (88,2,1),
 (88,5,5),
 (89,2,1),
 (89,5,2),
 (90,2,1),
 (90,5,2),
 (91,2,1),
 (91,5,1),
 (92,2,1),
 (92,5,5),
 (93,2,1),
 (93,5,4),
 (94,2,1),
 (94,5,5),
 (95,2,1),
 (95,5,1),
 (96,2,1),
 (96,5,9),
 (109,2,2),
 (109,5,2),
 (110,2,5),
 (110,5,3),
 (111,2,3),
 (111,5,3),
 (112,2,2),
 (112,5,2),
 (113,2,10),
 (113,5,7),
 (114,2,2),
 (114,5,2),
 (115,2,5),
 (115,5,4),
 (132,2,5),
 (133,2,5),
 (134,2,5),
 (135,2,5),
 (136,2,5),
 (137,2,5),
 (138,2,5),
 (139,2,5),
 (140,2,5);
/*!40000 ALTER TABLE `user_answers` ENABLE KEYS */;


--
-- Definition of table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` (`id`,`role`) VALUES 
 (1,'admin'),
 (2,'user');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
