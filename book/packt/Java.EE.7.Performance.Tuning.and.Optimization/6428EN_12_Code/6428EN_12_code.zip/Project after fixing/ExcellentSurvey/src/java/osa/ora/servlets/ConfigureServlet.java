/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */
package osa.ora.servlets;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.CommonBD;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.ConfigurationVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "ConfigureServlet", urlPatterns = {"/ConfigureServlet"})
public class ConfigureServlet extends HttpServlet {

    @EJB(beanName = "CommonBD")
    CommonBD commonBD;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        UserVO userAccount = (UserVO) request.getSession().getAttribute("USER");
        String serverIP = request.getParameter("serverIP");
        String serverPORT = request.getParameter("serverPORT");
        String useSSL = request.getParameter("useSSL");
        String serverUSER = request.getParameter("serverUSER");
        String serverPASS = request.getParameter("serverPASS");
        if (userAccount != null && userAccount.getUserRole() == IConstant.ADMIN_USER
                && serverIP != null && serverPORT != null && useSSL != null && serverUSER != null && serverPASS != null
                && !"".equals(serverIP) && !"".equals(serverPORT) && !"".equals(useSSL) && !"".equals(serverUSER)
                && !"".equals(serverPASS)) {
            //do other checks
            boolean useSSLFlag = true;
            try {
                useSSLFlag = Boolean.parseBoolean(useSSL);
            } catch (Exception ex) {
            }
            ConfigurationVO[] configs = new ConfigurationVO[5];
            configs[0] = new ConfigurationVO(IConstant.EMAIL_SERVER, serverIP);
            configs[1] = new ConfigurationVO(IConstant.EMAIL_SERVER_PORT, serverPORT);
            configs[2] = new ConfigurationVO(IConstant.SSL, "" + useSSLFlag);
            configs[3] = new ConfigurationVO(IConstant.EMAIL_SERVER_USER, serverUSER);
            configs[4] = new ConfigurationVO(IConstant.EMAIL_SERVER_PASSWORD, serverPASS);
            boolean updated = commonBD.setEmailConfig(configs, userAccount.getId());
            if (updated) {
                request.getSession().setAttribute("CONFIG", configs);
                request.getRequestDispatcher("/configConfirm.jsp").forward(request, response);
            } else {
                request.getSession().setAttribute("configError", "invalid");
                request.getRequestDispatcher("/config.jsp").forward(request, response);
            }
        } else {
            request.getSession().setAttribute("configError", "invalid");
            request.getRequestDispatcher("/config.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
