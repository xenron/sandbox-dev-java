/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dto;

import java.io.Serializable;

/**
 *
 * @author Osama Oransa
 */
public class SurveyVO implements Serializable {
    private int id;
    private int noOfQuestions;
    private String title;
    private boolean privateFlag;
    private int maxParticipation;
    private int currentParticipation;
    private String description;
    private int ownerId;
    private int status;
    private String statusDesc;
    private String[] surveyEmails;
    private QuestionVO[] surveryQuestions;

    /**
     * @return the noOfQuestions
     */
    public int getNoOfQuestions() {
        return noOfQuestions;
    }

    /**
     * @param noOfQuestions the noOfQuestions to set
     */
    public void setNoOfQuestions(int noOfQuestions) {
        this.noOfQuestions = noOfQuestions;
    }

    /**
     * @return the privateFlag
     */
    public boolean isPrivateFlag() {
        return privateFlag;
    }

    /**
     * @param privateFlag the privateFlag to set
     */
    public void setPrivateFlag(boolean privateFlag) {
        this.privateFlag = privateFlag;
    }

    /**
     * @return the maxParticipation
     */
    public int getMaxParticipation() {
        return maxParticipation;
    }

    /**
     * @param maxParticipation the maxParticipation to set
     */
    public void setMaxParticipation(int maxParticipation) {
        this.maxParticipation = maxParticipation;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the ownerId
     */
    public int getOwnerId() {
        return ownerId;
    }

    /**
     * @param ownerId the ownerId to set
     */
    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the statusDesc
     */
    public String getStatusDesc() {
        return statusDesc;
    }

    /**
     * @param statusDesc the statusDesc to set
     */
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    /**
     * @return the surveyEmails
     */
    public String[] getSurveyEmails() {
        return surveyEmails;
    }

    /**
     * @param surveyEmails the surveyEmails to set
     */
    public void setSurveyEmails(String[] surveyEmails) {
        this.surveyEmails = surveyEmails;
    }

    /**
     * @return the surveryQuestions
     */
    public QuestionVO[] getSurveryQuestions() {
        return surveryQuestions;
    }

    /**
     * @param surveryQuestions the surveryQuestions to set
     */
    public void setSurveryQuestions(QuestionVO[] surveryQuestions) {
        this.surveryQuestions = surveryQuestions;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the currentParticipation
     */
    public int getCurrentParticipation() {
        return currentParticipation;
    }

    /**
     * @param currentParticipation the currentParticipation to set
     */
    public void setCurrentParticipation(int currentParticipation) {
        this.currentParticipation = currentParticipation;
    }
}
