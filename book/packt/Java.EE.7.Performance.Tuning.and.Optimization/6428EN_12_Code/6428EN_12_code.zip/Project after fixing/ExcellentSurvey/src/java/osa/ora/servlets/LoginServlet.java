/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.servlets;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.AccountBD;
import osa.ora.bd.CommonBD;
import osa.ora.bd.SurveyBD;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.ConfigurationVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
    @EJB(beanName = "AccountBD")
    AccountBD accountBD;
    @EJB(beanName = "CommonBD")
    CommonBD commonBD;
    @EJB(beanName = "SurveyBD")
    SurveyBD surveyBD;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getParameter("action");
        Logger.getLogger(LoginServlet.class.getName()).log(Level.INFO, "Action="+action);
        //logout from system
        if("2".equals(action)){
            System.out.println("logout");
            request.getSession().removeAttribute("USER");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        UserVO userAccount = null;
        userAccount = (UserVO)request.getSession().getAttribute("USER");
        if(userAccount!=null){
            request.getRequestDispatcher("/home.jsp").forward(request, response);
            return;
        }
        if(username !=null && password!=null) {
            userAccount = accountBD.login(username, password);
            if(userAccount==null){
                request.getSession().setAttribute("loginError","invalid");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            } else{
                request.getSession().removeAttribute("loginError");
                //get user survey count to ensure user
                //do not create more than 15 surveys only
                int surveyCount=surveyBD.getUserSurveyCount(userAccount);
                userAccount.setCountOfSurvey(surveyCount);
                Logger.getLogger(LoginServlet.class.getName()).log(Level.INFO, "Current user's surveys count="+surveyCount);
                request.getSession().setAttribute("USER", userAccount);
                if(userAccount.getUserRole()==IConstant.ADMIN_USER){
                    ConfigurationVO[] configs=commonBD.getEmailConfig();
                    if(configs!=null) request.getSession().setAttribute("CONFIG", configs);
                }
                //load user survey's here ...
                request.getRequestDispatcher("/home.jsp").forward(request, response);                
            }
        }else {
            request.getSession().setAttribute("loginError","invalid");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
