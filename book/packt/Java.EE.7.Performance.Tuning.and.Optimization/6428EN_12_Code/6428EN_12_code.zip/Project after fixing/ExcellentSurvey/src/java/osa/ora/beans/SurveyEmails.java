/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Osama Oransa
 */
@Entity
@Table(name = "survey_emails")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SurveyEmails.findAll", query = "SELECT s FROM SurveyEmails s"),
    @NamedQuery(name = "SurveyEmails.findById", query = "SELECT s FROM SurveyEmails s WHERE s.id = :id"),
    @NamedQuery(name = "SurveyEmails.findByEmail", query = "SELECT s FROM SurveyEmails s WHERE s.email = :email"),
    @NamedQuery(name = "SurveyEmails.findBySurveyId", query = "SELECT s FROM SurveyEmails s WHERE s.surveyId = :surveyId"),
    @NamedQuery(name = "SurveyEmails.findBySubmitted", query = "SELECT s FROM SurveyEmails s WHERE s.submitted = :submitted")})
public class SurveyEmails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @NotNull
    @Column(name = "survey_id")
    private int surveyId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "submitted")
    private boolean submitted;

    public SurveyEmails() {
    }

    public SurveyEmails(Integer id) {
        this.id = id;
    }

    public SurveyEmails(Integer id, String email, int surveyId, boolean submitted) {
        this.id = id;
        this.email = email;
        this.surveyId = surveyId;
        this.submitted = submitted;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public boolean getSubmitted() {
        return submitted;
    }

    public void setSubmitted(boolean submitted) {
        this.submitted = submitted;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SurveyEmails)) {
            return false;
        }
        SurveyEmails other = (SurveyEmails) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.SurveyEmails[ id=" + id + " ]";
    }
    
}
