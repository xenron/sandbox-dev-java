/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Osama Oransa
 */
@Entity
@Table(name = "survey_questions")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SurveyQuestions.findAll", query = "SELECT s FROM SurveyQuestions s"),
    @NamedQuery(name = "SurveyQuestions.findBySurveyId", query = "SELECT s FROM SurveyQuestions s WHERE s.surveyQuestionsPK.surveyId = :surveyId"),
    @NamedQuery(name = "SurveyQuestions.findBySurveyQuestionId", query = "SELECT s FROM SurveyQuestions s WHERE s.surveyQuestionsPK.surveyQuestionId = :surveyQuestionId"),
    @NamedQuery(name = "SurveyQuestions.findBySequence", query = "SELECT s FROM SurveyQuestions s WHERE s.sequence = :sequence")})
public class SurveyQuestions implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SurveyQuestionsPK surveyQuestionsPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "sequence")
    private int sequence;

    public SurveyQuestions() {
    }

    public SurveyQuestions(SurveyQuestionsPK surveyQuestionsPK) {
        this.surveyQuestionsPK = surveyQuestionsPK;
    }

    public SurveyQuestions(SurveyQuestionsPK surveyQuestionsPK, int sequence) {
        this.surveyQuestionsPK = surveyQuestionsPK;
        this.sequence = sequence;
    }

    public SurveyQuestions(int surveyId, int surveyQuestionId) {
        this.surveyQuestionsPK = new SurveyQuestionsPK(surveyId, surveyQuestionId);
    }

    public SurveyQuestionsPK getSurveyQuestionsPK() {
        return surveyQuestionsPK;
    }

    public void setSurveyQuestionsPK(SurveyQuestionsPK surveyQuestionsPK) {
        this.surveyQuestionsPK = surveyQuestionsPK;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (surveyQuestionsPK != null ? surveyQuestionsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SurveyQuestions)) {
            return false;
        }
        SurveyQuestions other = (SurveyQuestions) object;
        if ((this.surveyQuestionsPK == null && other.surveyQuestionsPK != null) || (this.surveyQuestionsPK != null && !this.surveyQuestionsPK.equals(other.surveyQuestionsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.SurveyQuestions[ surveyQuestionsPK=" + surveyQuestionsPK + " ]";
    }
    
}
