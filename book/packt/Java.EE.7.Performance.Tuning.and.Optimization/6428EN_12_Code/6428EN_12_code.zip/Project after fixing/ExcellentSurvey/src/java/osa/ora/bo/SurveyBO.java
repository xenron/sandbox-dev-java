/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */
package osa.ora.bo;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.NotificationTemplate;
import osa.ora.beans.QuestionRatingType;
import osa.ora.beans.Questions;
import osa.ora.beans.Survey;
import osa.ora.beans.SurveyEmails;
import osa.ora.dao.CommonDAO;
import osa.ora.dao.SurveyDAO;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.RatingVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class SurveyBO {

    @EJB(beanName = "SurveyDAO")
    SurveyDAO surveyDAO;
    @EJB(beanName = "CommonDAO")
    CommonDAO commonDAO;

    /**
     * load all ratings
     *
     * @return
     */
    public RatingVO[] loadAllRatings() {
        RatingVO[] ratingListVO = null;
        QuestionRatingType[] ratings = surveyDAO.loadAllRatings();
        if (ratings == null || ratings.length == 0) {
            Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"ratings not found");
            return null;
        } else {
            ratingListVO = BOMappingHelper.mapUserToUserDTO(ratings, ratingListVO);
        }
        return ratingListVO;
    }

    /**
     * create new survey
     *
     * @param userVO 
     * @param surveyVO
     * @return
     */
    public boolean createNewSurvey(UserVO userVO,SurveyVO surveyVO) {
        boolean results = false;
        AuditTrailVO audit = surveyDAO.createNewSurvey(surveyVO, userVO.getId());
        if (audit == null) {
            return results;
        } else {
            results = true;
            commonDAO.createAuditTrail(audit);
            //get the activation notification
            NotificationTemplate template = commonDAO.getNotificationForAction(IConstant.SURVEY_CREATED);
            String body = commonDAO.replaceParameters(template.getBody(), new String[]{userVO.getName(), "" + audit.getReason()});
            //send email messages
            commonDAO.sendMail(new String [] {userVO.getEmail()}, template.getSubject(), body, null, null, false);
        }
        return results;
    }

    /**
     * get all managed surveys for a user
     *
     * @param userVO
     * @return
     */
    public SurveyVO[] getMySurveyList(UserVO userVO) {
        SurveyVO[] surveyListVO = null;
        Survey[] surveys = surveyDAO.getMySurveyList(userVO);
        if (surveys == null || surveys.length == 0) {
            Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"surveys not found");
            return null;
        } else {
            for (Survey survey : surveys) {
                Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"surevy Id="+survey.getId());
            }
            surveyListVO = BOMappingHelper.mapSurveyToSurveyDTO(surveys, surveyListVO);
            //set status desc
            for (SurveyVO survey : surveyListVO) {
                survey.setStatusDesc(surveyDAO.getStatusDesc(survey.getStatus()));
                survey.setCurrentParticipation(surveyDAO.getCurrentSurveyParticipation(survey.getId()));
            }
        }
        return surveyListVO;
    }

    /**
     * activate a survey and send its configured mails by the owner
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public boolean activateSurveyAndSendEmails(UserVO userVO, int surveyId) {
        boolean results = surveyDAO.activateSurvey(surveyId, userVO.getId());
        if (results) {
            AuditTrailVO audit = new AuditTrailVO();
            audit.setUserId(userVO.getId());
            audit.setActionId(IConstant.SURVEY_ACTIVATED);
            audit.setDate(new Date());
            audit.setReason("Survey Activated :" + surveyId);
            commonDAO.createAuditTrail(audit);
            SurveyEmails[] emails = surveyDAO.getSurveyEmails(surveyId);
            if (emails != null && emails.length > 0) {
                String[] emailAdresses = new String[emails.length];
                int i = 0;
                for (SurveyEmails email : emails) {
                    Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"Sending emails:" + email);
                    emailAdresses[i] = email.getEmail();
                    i++;
                }
                //get the activation notification
                NotificationTemplate template = commonDAO.getNotificationForAction(IConstant.SURVEY_ACTIVATED);
                String body = commonDAO.replaceParameters(template.getBody(), new String[]{userVO.getName(), "" + surveyId});
                //send email messages
                commonDAO.sendMail(emailAdresses, template.getSubject(), body, null, null, false);
            }
        }
        return results;
    }

    /**
     * close survey for participation by the owner
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public boolean closeSurvey(UserVO userVO, int surveyId) {
        boolean closed = surveyDAO.closeSurvey(surveyId, userVO.getId());
        if (closed) {
            AuditTrailVO audit = new AuditTrailVO();
            audit.setUserId(userVO.getId());
            audit.setActionId(IConstant.SURVEY_CLOSED);
            audit.setDate(new Date());
            audit.setReason("Survey closed :" + surveyId);
            commonDAO.createAuditTrail(audit);
        }
        return closed;
    }

    /**
     * delete survey by the owner
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public boolean deleteSurvey(UserVO userVO, int surveyId) {
        boolean deleted = surveyDAO.deleteSurvey(surveyId, userVO.getId());
        if (deleted) {
            AuditTrailVO audit = new AuditTrailVO();
            audit.setUserId(userVO.getId());
            audit.setActionId(IConstant.SURVEY_DELETED);
            audit.setDate(new Date());
            audit.setReason("Survey deleted :" + surveyId);
            commonDAO.createAuditTrail(audit);
        }
        return deleted;
    }

    /**
     * create, save and download report by the owner
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public String getSurveyReport(UserVO userVO, int surveyId) {
        String report = surveyDAO.getSurveyReport(surveyId);
        if (report != null) {
            AuditTrailVO audit = new AuditTrailVO();
            audit.setUserId(userVO.getId());
            audit.setActionId(IConstant.SURVEY_RESULT_SENT);
            audit.setDate(new Date());
            audit.setReason("Report generated for survey " + surveyId);
            commonDAO.createAuditTrail(audit);
        }
        return report;
    }

    /**
     * Get list of surveys the user can participate in
     *
     * @param userVO
     * @return
     */
    public SurveyVO[] getAvailableSurveyList(UserVO userVO) {
        SurveyVO[] surveyListVO = null;
        Survey[] surveyList = surveyDAO.getAvailableSurveyList(userVO);
        if (surveyList == null || surveyList.length == 0) {
            Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"surveys not found");
            return null;
        } else {
            for (Survey survey : surveyList) {
                Logger.getLogger(SurveyBO.class.getName()).log(Level.INFO,"Survey Id="+survey.getId());
            }
            surveyListVO = BOMappingHelper.mapSurveyToSurveyDTO(surveyList, surveyListVO);
            //set status desc
            for (SurveyVO survey : surveyListVO) {
                survey.setStatusDesc(surveyDAO.getStatusDesc(survey.getStatus()));
                survey.setCurrentParticipation(surveyDAO.getCurrentSurveyParticipation(survey.getId()));
            }
        }
        return surveyListVO;
    }

    /**
     * get survey details including questions
     *
     * @param userVO
     * @param surveyId
     * @return
     */
    public SurveyVO getSurveyDetails(UserVO userVO, int surveyId) {
        Survey survey = surveyDAO.getSurveyDetails(userVO, surveyId);
        if (survey != null) {
            Questions[] questions = surveyDAO.getSurveyQuestionList(surveyId);
            if (questions != null && questions.length > 0) {
                SurveyVO surveyDetails = BOMappingHelper.mapSurveyItemToSurveyDTO(survey, questions);
                return surveyDetails;
            }
        }
        return null;
    }

    /**
     * submit survey participation (survey answers) if not already submitted
     * before and number of participations do not exceed the max configured
     * number.
     *
     * @param userVO
     * @param userAnswerVOs
     * @param surveyId
     * @return
     */
    public boolean submitSurveyAnswers(UserVO userVO, UserAnswerVO[] userAnswerVOs, int surveyId) {
        boolean submitted = surveyDAO.submitSurveyAnswers(userAnswerVOs, userVO.getId(), surveyId);
        if (submitted) {
            AuditTrailVO audit = new AuditTrailVO();
            audit.setUserId(userVO.getId());
            audit.setActionId(6);
            audit.setDate(new Date());
            audit.setReason("Survey submitted :" + surveyId);
            commonDAO.createAuditTrail(audit);
        }
        return submitted;
    }
    /**
     * Method to get count of surveys owned by this user
     * @param userVO
     * @return 
     */
    public int getUserSurveyCount(UserVO userVO) {
        return surveyDAO.getUserSurveyCount(userVO.getId());
    }
}
