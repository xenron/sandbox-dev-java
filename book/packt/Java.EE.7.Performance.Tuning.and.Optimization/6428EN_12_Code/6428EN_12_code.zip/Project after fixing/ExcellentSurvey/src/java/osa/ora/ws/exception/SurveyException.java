/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.ws.exception;

/**
 *
 * @author Osama Oransa
 */
public class SurveyException extends Exception {
    /**
     * constructor that take exception message
     * @param message 
     */
    public SurveyException(String message){
        super(message);
    }
}
