/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */
package osa.ora.dto;

import java.io.Serializable;

/**
 *
 * @author Osama Oransa
 */
public class UserVO implements Serializable {
    private int id;
    private String name;
    private String email;
    private String password;
    private boolean active;
    private int userRole;
    private int countOfSurvey;
    private String userRoleDesc;
    public UserVO(){
        
    }    
    public UserVO(Integer id, String name, String email, String password, boolean active, int userRole, String userRoleDesc) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.active = active;
        this.userRole=userRole;
        this.userRoleDesc= userRoleDesc;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * @return the userRole
     */
    public int getUserRole() {
        return userRole;
    }

    /**
     * @param userRole the userRole to set
     */
    public void setUserRole(int userRole) {
        this.userRole = userRole;
    }

    /**
     * @return the userRoleDesc
     */
    public String getUserRoleDesc() {
        return userRoleDesc;
    }

    /**
     * @param userRoleDesc the userRoleDesc to set
     */
    public void setUserRoleDesc(String userRoleDesc) {
        this.userRoleDesc = userRoleDesc;
    }

    /**
     * @return the countOfSurvey
     */
    public int getCountOfSurvey() {
        return countOfSurvey;
    }

    /**
     * @param countOfSurvey the countOfSurvey to set
     */
    public void setCountOfSurvey(int countOfSurvey) {
        this.countOfSurvey = countOfSurvey;
    }

}
