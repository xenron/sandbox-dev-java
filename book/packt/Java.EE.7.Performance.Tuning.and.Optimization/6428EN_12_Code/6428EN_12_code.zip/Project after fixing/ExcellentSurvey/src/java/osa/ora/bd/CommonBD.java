/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bd;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.bo.CommonBO;
import osa.ora.dto.ConfigurationVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class CommonBD {
    @EJB(beanName = "CommonBO")
    CommonBO commonBO;
    /**
     * get email configurations
     * @return 
     */
    public ConfigurationVO[] getEmailConfig() {
        return commonBO.getEmailConfig();
    }
    /**
     * update email configurations
     * @param configVO
     * @param userId
     * @return 
     */
    public boolean setEmailConfig(ConfigurationVO[] configVO,int userId) {
        return commonBO.setEmailConfig(configVO, userId);
    }
}
