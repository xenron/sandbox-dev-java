/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Osama Oransa
 */
@Entity
@Table(name = "user_answers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserAnswers.findAll", query = "SELECT u FROM UserAnswers u"),
    @NamedQuery(name = "UserAnswers.findByQuestionId", query = "SELECT u FROM UserAnswers u WHERE u.userAnswersPK.questionId = :questionId"),
    @NamedQuery(name = "UserAnswers.findByUserId", query = "SELECT u FROM UserAnswers u WHERE u.userAnswersPK.userId = :userId"),
    @NamedQuery(name = "UserAnswers.findByAnswer", query = "SELECT u FROM UserAnswers u WHERE u.answer = :answer")})
public class UserAnswers implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UserAnswersPK userAnswersPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "answer")
    private int answer;

    public UserAnswers() {
    }

    public UserAnswers(UserAnswersPK userAnswersPK) {
        this.userAnswersPK = userAnswersPK;
    }

    public UserAnswers(UserAnswersPK userAnswersPK, int answer) {
        this.userAnswersPK = userAnswersPK;
        this.answer = answer;
    }

    public UserAnswers(int questionId, int userId) {
        this.userAnswersPK = new UserAnswersPK(questionId, userId);
    }

    public UserAnswersPK getUserAnswersPK() {
        return userAnswersPK;
    }

    public void setUserAnswersPK(UserAnswersPK userAnswersPK) {
        this.userAnswersPK = userAnswersPK;
    }

    public int getAnswer() {
        return answer;
    }

    public void setAnswer(int answer) {
        this.answer = answer;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userAnswersPK != null ? userAnswersPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserAnswers)) {
            return false;
        }
        UserAnswers other = (UserAnswers) object;
        if ((this.userAnswersPK == null && other.userAnswersPK != null) || (this.userAnswersPK != null && !this.userAnswersPK.equals(other.userAnswersPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.UserAnswers[ userAnswersPK=" + userAnswersPK + " ]";
    }
    
}
