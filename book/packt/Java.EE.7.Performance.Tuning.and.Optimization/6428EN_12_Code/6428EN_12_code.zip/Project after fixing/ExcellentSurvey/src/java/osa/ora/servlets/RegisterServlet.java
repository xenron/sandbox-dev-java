/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.servlets;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.AccountBD;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {
    @EJB(beanName = "AccountBD")
    AccountBD accountBD;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getParameter("action");
        Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "Action="+action);
        //activate user account
        if("2".equals(action)){
            System.out.println("activate user");
            String email=request.getParameter("email");
            System.out.println("email="+email);
            String url=request.getRequestURL().toString();
            int n=url.lastIndexOf("/");
            url=url.substring(0,n);
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "URL="+url);
            boolean activated = accountBD.activateUser(email,url);
            if(activated) {
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "register, now activate your account");
                request.getRequestDispatcher("/activated.jsp").forward(request, response);                                
            }else{
                request.getSession().setAttribute("ERROR","Failed to activate user!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);                                    
            }
            return;
        }
        //register here
        System.out.println("inside registration");
        String username=request.getParameter("re_username");
        String password=request.getParameter("re_password");
        String email=request.getParameter("re_email");
        String emailConfirm=request.getParameter("re_email_confirm");
        UserVO userAccount = null;
        userAccount = (UserVO)request.getSession().getAttribute("USER");
        if(userAccount!=null){
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "Already logged in ... don't allow registration");
            request.getRequestDispatcher("/home.jsp").forward(request, response);
            return;
        }
        if(username !=null && password!=null && email!=null && emailConfirm!=null &&
                !"".equals(username) && !"".equals(password) && !"".equals(email) && !"".equals(emailConfirm)
                && email.equalsIgnoreCase(emailConfirm)) {
            try {
                String url=request.getRequestURL().toString();
                System.out.println("URL="+url);
                int n=url.lastIndexOf("/");
                url=url.substring(0,n)+"/RegisterServlet?action=2&email="+email+"&RegisterServlet";
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "URL="+url);
                userAccount = accountBD.registerUser(username, password, email,url);
            } catch (Exception ex) {
                if("User already exist".equals(ex.getMessage())){
                    request.getSession().setAttribute("registerError","User already exist!");
                    request.getRequestDispatcher("/index.jsp").forward(request, response);
                    return;
                }else{
                    request.getSession().setAttribute("registerError","Unexpected error!");
                    request.getRequestDispatcher("/index.jsp").forward(request, response);                    
                    return;
                }
            }
            if(userAccount==null){
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "Failed to register this user!!");
                request.getSession().setAttribute("registerError","Unable to register this user!");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            } else{
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "register, now activate your account");
                request.getRequestDispatcher("/register.jsp").forward(request, response);                
            }
        }else {
            request.getSession().setAttribute("registerError","Missing required details!");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
