/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dto;

/**
 *
 * @author Osama Oransa
 */
public class ConfigurationVO {
    private String configkey;
    private String configValue;
    /**
     * public constructor
     * @param configkey
     * @param configValue 
     */
    public ConfigurationVO(String configkey,String configValue){
        this.configkey=configkey;
        this.configValue=configValue;
    }
    /**
     * @return the configkey
     */
    public String getConfigkey() {
        return configkey;
    }

    /**
     * @param configkey the configkey to set
     */
    public void setConfigkey(String configkey) {
        this.configkey = configkey;
    }

    /**
     * @return the configValue
     */
    public String getConfigValue() {
        return configValue;
    }

    /**
     * @param configValue the configValue to set
     */
    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }
    
}
