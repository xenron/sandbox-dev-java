/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dto;

import java.io.Serializable;

/**
 *
 * @author Osama Oransa
 */
public class QuestionVO implements Serializable{
    private int id;
    private String question;
    private String body;
    private int sequence;
    private int ratingtypeId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * @param question the question to set
     */
    public void setQuestion(String question) {
        this.question = question;
    }

    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * @return the ratingtypeId
     */
    public int getRatingtypeId() {
        return ratingtypeId;
    }

    /**
     * @param ratingtypeId the ratingtypeId to set
     */
    public void setRatingtypeId(int ratingtypeId) {
        this.ratingtypeId = ratingtypeId;
    }

    /**
     * @return the sequence
     */
    public int getSequence() {
        return sequence;
    }

    /**
     * @param sequence the sequence to set
     */
    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

}
