/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.servlets;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.SurveyBD;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "ManageServlet", urlPatterns = {"/ManageServlet"})
public class ManageServlet extends HttpServlet {
    @EJB(beanName = "SurveyBD")
    SurveyBD surveyBD;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getParameter("action");
        Logger.getLogger(ManageServlet.class.getName()).log(Level.INFO, "Action="+action);
        UserVO userAccount = (UserVO)request.getSession().getAttribute("USER");
        if(action==null || "1".equals(action)){ //list all surveys
            SurveyVO[] mySurveys=surveyBD.getMySurveyList(userAccount);
            request.getSession().setAttribute("SURVEYLIST", mySurveys);
            request.getRequestDispatcher("/manage.jsp").forward(request, response);
        }else if("2".equals(action)){ //activate survey
            String id=request.getParameter("id");
            if(id==null){
                request.getRequestDispatcher("/manage.jsp").forward(request, response);
            }else {
                int surveyId=-1;
                try{
                    surveyId=Integer.parseInt(id);
                }catch(Exception ex){
                }
                boolean activated=surveyBD.activateSurveyAndSendEmails(userAccount,surveyId);
                if(activated){
                    SurveyVO[] mySurveys=surveyBD.getMySurveyList(userAccount);
                    request.getSession().setAttribute("SURVEYLIST", mySurveys);
                    request.getSession().setAttribute("MESSAGE", "Survey "+surveyId+" activated successfully");
                }else{
                    request.getSession().setAttribute("MESSAGE", "Failed to activate survey "+surveyId);
                }
                request.getRequestDispatcher("/manage.jsp").forward(request, response);
            }
        }else if("3".equals(action)){ //close survey
            String id=request.getParameter("id");
            if(id==null){
                request.getSession().setAttribute("ERROR","Invalid survey ID!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);                    
            }else {
                int surveyId=-1;
                try{
                    surveyId=Integer.parseInt(id);
                }catch(Exception ex){
                }
                boolean closed=surveyBD.closeSurvey(userAccount,surveyId);
                if(closed){
                    SurveyVO[] mySurveys=surveyBD.getMySurveyList(userAccount);
                    request.getSession().setAttribute("SURVEYLIST", mySurveys);
                    request.getSession().setAttribute("MESSAGE", "Survey "+surveyId+" closed successfully");
                }else{
                    request.getSession().setAttribute("MESSAGE", "Failed to close survey "+surveyId);
                }
                request.getRequestDispatcher("/manage.jsp").forward(request, response);
            }
        }else if("4".equals(action)){ //delete survey
            String id=request.getParameter("id");
            if(id==null){
                request.getSession().setAttribute("ERROR","Invalid survey ID!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);                    
            }else {
                int surveyId=-1;
                try{
                    surveyId=Integer.parseInt(id);
                }catch(NumberFormatException ex){
                }
                boolean deleted=surveyBD.deleteSurvey(userAccount,surveyId);
                if(deleted){
                    SurveyVO[] mySurveys=surveyBD.getMySurveyList(userAccount);
                    request.getSession().setAttribute("SURVEYLIST", mySurveys);
                    request.getSession().setAttribute("MESSAGE", "Survey "+surveyId+" deleted successfully");
                }else{
                    request.getSession().setAttribute("MESSAGE", "Failed to delete survey "+surveyId);
                }
                request.getRequestDispatcher("/manage.jsp").forward(request, response);
            }
        }else if("5".equals(action)){ //download report
            String id=request.getParameter("id");
            if(id==null){
                request.getSession().setAttribute("ERROR","Invalid survey ID!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);                    
            }else {
                int surveyId=-1;
                try{
                    surveyId=Integer.parseInt(id);
                }catch(NumberFormatException ex){
                }
                String report=surveyBD.getSurveyReport(userAccount,surveyId);
                if(report!=null){
                    response.setHeader("Cache-Control", "no-cache");
                    response.setHeader("Pragma", "no-cache");
                    response.setDateHeader("Expires", 0L);
                    response.setContentLength(report.length());
                    response.setContentType("text/html");
                    response.setHeader("Content-Disposition", "attachment;filename=survey_report_"+surveyId+".html");
                    try (ServletOutputStream outputstream = response.getOutputStream()) {
                        outputstream.write(report.getBytes());
                        outputstream.flush();
                    }
                }else{
                    request.getSession().setAttribute("ERROR","Can't retireve report for this survey!");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);
                }
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
