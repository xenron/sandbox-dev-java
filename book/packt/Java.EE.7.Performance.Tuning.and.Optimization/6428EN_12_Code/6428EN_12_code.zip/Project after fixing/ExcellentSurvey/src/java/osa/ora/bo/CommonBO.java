/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bo;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.Configuration;
import osa.ora.dao.CommonDAO;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.ConfigurationVO;
import osa.ora.util.EmailSender;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class CommonBO{    
    @EJB(beanName = "CommonDAO")
    CommonDAO commonDAO;
    EmailSender emailSender= EmailSender.getInstance();
    public ConfigurationVO[] getEmailConfig() {
        ConfigurationVO[] configurationVO = null;
        Configuration[] configs=commonDAO.getEmailConfig();
        if(configs==null){
            Logger.getLogger(CommonBO.class.getName()).log(Level.INFO,"configurations not found");
            return null;
        }
        return configurationVO;
    }  

    public boolean setEmailConfig(ConfigurationVO[] configVO, int userId) {
        ConfigurationVO[] configurationVO = null;
        boolean updated=commonDAO.setEmailConfig(configVO);
        if(!updated){
            Logger.getLogger(CommonBO.class.getName()).log(Level.INFO,"configurations are not updated");
            return false;
        }else{
            AuditTrailVO auditTrail=new AuditTrailVO();
            auditTrail.setActionId(IConstant.UPDATE_MAIL_CONFIGURATIONS);
            auditTrail.setUserId(userId);
            auditTrail.setDate(new Date());
            auditTrail.setReason("Update email configurations");
            commonDAO.createAuditTrail(auditTrail);
        }
        return true;
    }
}
