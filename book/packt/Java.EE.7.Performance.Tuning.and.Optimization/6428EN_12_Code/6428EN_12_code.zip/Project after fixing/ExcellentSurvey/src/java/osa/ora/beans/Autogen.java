/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Osama Oransa
 */
@Entity
@Table(name = "autogen")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Autogen.findAll", query = "SELECT a FROM Autogen a"),
    @NamedQuery(name = "Autogen.findByTabKey", query = "SELECT a FROM Autogen a WHERE a.tabKey = :tabKey"),
    @NamedQuery(name = "Autogen.findByTabValue", query = "SELECT a FROM Autogen a WHERE a.tabValue = :tabValue")})
public class Autogen implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "tab_key")
    private String tabKey;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tab_value")
    private int tabValue;

    public Autogen() {
    }

    public Autogen(String tabKey) {
        this.tabKey = tabKey;
    }

    public Autogen(String tabKey, int tabValue) {
        this.tabKey = tabKey;
        this.tabValue = tabValue;
    }

    public String getTabKey() {
        return tabKey;
    }

    public void setTabKey(String tabKey) {
        this.tabKey = tabKey;
    }

    public int getTabValue() {
        return tabValue;
    }

    public void setTabValue(int tabValue) {
        this.tabValue = tabValue;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tabKey != null ? tabKey.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Autogen)) {
            return false;
        }
        Autogen other = (Autogen) object;
        if ((this.tabKey == null && other.tabKey != null) || (this.tabKey != null && !this.tabKey.equals(other.tabKey))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.Autogen[ tabKey=" + tabKey + " ]";
    }
    
}
