/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.ws;

import javax.ejb.EJB;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import osa.ora.bo.AccountBO;
import osa.ora.bo.SurveyBO;
import osa.ora.dto.RatingVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;
import osa.ora.ws.exception.SurveyException;

/**
 *
 * @author Osama Oransa
 */
@WebService(serviceName = "SurveyWebService")
@Stateless()
public class SurveyWebService {
    @EJB(beanName = "SurveyBO")
    SurveyBO surveyBO;
    @EJB(beanName = "AccountBO")
    AccountBO accountBO;

    /**
     * method to load all question rating types
     * @param username
     * @param password
     * @return
     * @throws SurveyException 
     */
    @WebMethod(operationName = "loadAllSurveyRatings")
    public RatingVO[] loadAllSurveyRatings(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password) throws SurveyException{
        authenticateUser(username, password);
        return surveyBO.loadAllRatings();
    }
    /**
     * method to create new survey
     * @param username 
     * @param password 
     * @param surveyVO 
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "createNewSurvey")
    public boolean createNewSurvey(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password,@WebParam(name = "surveyVO") final SurveyVO surveyVO) throws SurveyException {
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.createNewSurvey(userVO, surveyVO);
    }
    /**
     * private method to authenticate web service call
     * @param username
     * @param password
     * @return
     * @throws SurveyException 
     */
    private UserVO authenticateUser(final String username, final String password) throws SurveyException {
        final UserVO userVO=accountBO.login(username, password);
        if(userVO==null){
            throw new SurveyException("Invalid login!");
        }
        return userVO;
    }
    /**
     * method to get all survey list owned by this user
     * @param username 
     * @param password 
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "getMySurveyList")
    public SurveyVO[] getMySurveyList(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password) throws SurveyException{
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.getMySurveyList(userVO);
    }
    /**
     * method to activate survey and send email to survey mails
     * @param username 
     * @param password 
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "activateSurveyAndSendEmails")
    public boolean activateSurveyAndSendEmails(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password,@WebParam(name = "surveyId") final int surveyId) throws SurveyException{
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.activateSurveyAndSendEmails(userVO,surveyId);
    }
    /**
     * method to close survey
     * @param username 
     * @param password 
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "closeSurvey")
    public boolean closeSurvey(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password,@WebParam(name = "surveyId") final int surveyId) throws SurveyException{
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.closeSurvey(userVO,surveyId);
    }
    /**
     * method to delete survey
     * @param username 
     * @param password 
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "deleteSurvey")
    public boolean deleteSurvey(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password,@WebParam(name = "surveyId") final int surveyId) throws SurveyException{
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.deleteSurvey(userVO,surveyId);
    }
    /**
     * method to get survey report in HTML format
     * @param username 
     * @param password 
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "getSurveyReport")
    public String getSurveyReport(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password,@WebParam(name = "surveyId") final int surveyId) throws SurveyException{
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.getSurveyReport(userVO,surveyId);
    }
    /**
     * Method to get all available survey list that the user
     * can vote on them.
     * @param username 
     * @param password 
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "getAvailableSurveyList")
    public SurveyVO[] getAvailableSurveyList(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password) throws SurveyException {
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.getAvailableSurveyList(userVO);
    }
    /**
     * get survey details for certain survey.
     * @param username 
     * @param password 
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "getSurveyDetails")
    public SurveyVO getSurveyDetails(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password, @WebParam(name = "surveyId") final int surveyId) throws SurveyException {
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.getSurveyDetails(userVO,surveyId);
     }
    /**
     * method to submit survey answers
     * @param username 
     * @param password 
     * @param userAnswerVOs
     * @param surveyId
     * @return 
     * @throws SurveyException 
     */
    @WebMethod(operationName = "submitSurveyAnswers")
    public boolean submitSurveyAnswers(@WebParam(name = "username") final String username,@WebParam(name = "password") final String password, @WebParam(name = "userAnswerVOs") final UserAnswerVO[] userAnswerVOs,@WebParam(name = "surveyId") final int surveyId) throws SurveyException {
        final UserVO userVO=authenticateUser(username, password);
        return surveyBO.submitSurveyAnswers(userVO,userAnswerVOs, surveyId);
    }
    
}
