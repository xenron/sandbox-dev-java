/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dao;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.QuestionRatingType;
import osa.ora.beans.Questions;
import osa.ora.beans.Survey;
import osa.ora.beans.SurveyEmails;
import osa.ora.dao.helper.DAOHelper;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class SurveyDAO {
    @EJB(beanName = "DAOHelper")
    DAOHelper helper;
    /**
     * load all question rating types
     * @return 
     */
    public QuestionRatingType[] loadAllRatings(){
        return helper.loadAllRatings();
    }    
    /**
     * create new survey 
     * @param surveyVO
     * @param userId 
     * @return 
     */
    public AuditTrailVO createNewSurvey(SurveyVO surveyVO, int userId) {
        return helper.createNewSurvey(surveyVO, userId);
    }
    /**
     * get managed survey list for a user
     * @param userVO
     * @return 
     */
    public Survey[] getMySurveyList(UserVO userVO) {
        return helper.getMySurveyList(userVO);
    }
    /**
     * get status description
     * @param status
     * @return 
     */
    public String getStatusDesc(int status){
        return helper.getStatusDesc(status);
    }
    /**
     * get current survey participation count
     * @param surveyId
     * @return 
     */
    public int getCurrentSurveyParticipation(int surveyId) {
        return helper.getCurrentSurveyParticipation(surveyId);
    }
    /**
     * activate survey for participation by the owner
     * @param surveyId
     * @param userId
     * @return 
     */
    public boolean activateSurvey(int surveyId, int userId) {
        return helper.activateSurvey(surveyId, userId);
    }
    /**
     * get survey mails
     * @param surveyId
     * @return 
     */
    public SurveyEmails[] getSurveyEmails(int surveyId) {
        return helper.getSurveyEmails(surveyId);
    }
    /**
     * close survey by the owner
     * @param surveyId
     * @param userId
     * @return 
     */
    public boolean closeSurvey(int surveyId, int userId) {
        return helper.closeSurvey(surveyId, userId);
    }
    /**
     * delete a survey by the owner
     * @param surveyId
     * @param userId
     * @return 
     */
    public boolean deleteSurvey(int surveyId, int userId) {
        return helper.deleteSurvey(surveyId, userId);
    }
    /**
     * create, save, and download survey report 
     * @param surveyId
     * @return 
     */
    public String getSurveyReport(int surveyId) {
        return helper.getSurveyReport(surveyId);
    }
    /**
     * get all available surveys for participation for this user
     * @param userVO
     * @return 
     */
    public Survey[] getAvailableSurveyList(UserVO userVO) {
        return helper.getAvailableSurveyList(userVO);
    }
    /**
     * get survey details
     * @param userVO
     * @param surveyId
     * @return 
     */
    public Survey getSurveyDetails(UserVO userVO, int surveyId) {
        return helper.getSurveyDetails(userVO, surveyId);
    }
    /**
     * get survey question list
     * @param surveyId
     * @return 
     */
    public Questions[] getSurveyQuestionList(int surveyId) {
        return helper.getSurveyQuestionList(surveyId);
    }
    /**
     * submit survey questions for a user if not already submitted
     * and number of survey participants do not exceed the max value.
     * @param userAnswerVOs
     * @param userId
     * @param surveyId
     * @return 
     */
    public boolean submitSurveyAnswers(UserAnswerVO[] userAnswerVOs, int userId,int surveyId) {
        return helper.submitSurveyAnswers(userAnswerVOs,userId,surveyId);
    }

    public int getUserSurveyCount(Integer userId) {
        return helper.getUserSurveyCount(userId);
    }
    
}
