/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dao.helper;

/**
 *
 * @author Osama Oransa
 */
public class IConstant {
    // system actions
    public static final int SURVEY_CREATED=1;
    public static final int SURVEY_UPDATED=2;
    public static final int SURVEY_ACTIVATED=3;
    public static final int SURVEY_CLOSED=4;
    public static final int SURVEY_DELETED=5;
    public static final int SURVEY_SUBMITTED=6;
    public static final int SURVEY_RESULT_SENT=7;
    public static final int USER_LOGIN=8;
    public static final int USER_REGISTERED=9;
    public static final int USER_ACTIVATED=10;
    public static final int UPDATE_MAIL_CONFIGURATIONS=10;
    // syrvey status
    public static final int CREATED_STATUS=1;
    public static final int ACTIVE_STATUS=2;
    public static final int CLOSED_STATUS=3;
    public static final int REPORT_READY=4;
    //user types
    public static final int ADMIN_USER=1;
    public static final int NORMAL_USER=2;
    //emial configurations
    public static final String EMAIL_SERVER="EMAIL_SERVER"; 
    public static final String EMAIL_SERVER_PORT="EMAIL_SERVER_PORT";
    public static final String SSL="SSL";
    public static final String EMAIL_SERVER_USER="EMAIL_SERVER_USER";
    public static final String EMAIL_SERVER_PASSWORD="EMAIL_SERVER_PASSWORD";
    //max allowed customer surveys
    public static final int MAX_USER_SURVEYS=15;
    
}
