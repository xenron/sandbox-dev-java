/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.dao;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.User;
import osa.ora.dao.helper.DAOHelper;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class AccountDAO {
    @EJB(beanName = "DAOHelper")
    DAOHelper helper;
    /**
     * login method
     * @param username
     * @param password
     * @return 
     */
    public User login(String username, String password) {
        return helper.login(username, password);
    }
    /**
     * register new user 
     * @param username
     * @param password
     * @param email
     * @return
     * @throws Exception
     */
    public User registerUser(String username, String password, String email) throws Exception {
        return helper.registerUser(username, password, email);
    }
    /**
     * activate user
     * @param email
     * @return
     */
    public User activateUser(String email) {
        return helper.activateUser(email);
    }
    
}
