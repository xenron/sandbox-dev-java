/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Osama Oransa
 */
@Entity
@Table(name = "configuration")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Configuration.findAll", query = "SELECT c FROM Configuration c"),
    @NamedQuery(name = "Configuration.findByConfigkey", query = "SELECT c FROM Configuration c WHERE c.configkey = :configkey"),
    @NamedQuery(name = "Configuration.findByConfigValue", query = "SELECT c FROM Configuration c WHERE c.configValue = :configValue")})
public class Configuration implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "Config_key")
    private String configkey;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 80)
    @Column(name = "config_value")
    private String configValue;

    public Configuration() {
    }

    public Configuration(String configkey) {
        this.configkey = configkey;
    }

    public Configuration(String configkey, String configValue) {
        this.configkey = configkey;
        this.configValue = configValue;
    }

    public String getConfigkey() {
        return configkey;
    }

    public void setConfigkey(String configkey) {
        this.configkey = configkey;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (configkey != null ? configkey.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Configuration)) {
            return false;
        }
        Configuration other = (Configuration) object;
        if ((this.configkey == null && other.configkey != null) || (this.configkey != null && !this.configkey.equals(other.configkey))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.Configuration[ configkey=" + configkey + " ]";
    }
    
}
