/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Osama Oransa
 */
@Embeddable
public class SurveyQuestionsPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "survey_id")
    private int surveyId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "survey_question_id")
    private int surveyQuestionId;

    public SurveyQuestionsPK() {
    }

    public SurveyQuestionsPK(int surveyId, int surveyQuestionId) {
        this.surveyId = surveyId;
        this.surveyQuestionId = surveyQuestionId;
    }

    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public int getSurveyQuestionId() {
        return surveyQuestionId;
    }

    public void setSurveyQuestionId(int surveyQuestionId) {
        this.surveyQuestionId = surveyQuestionId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) surveyId;
        hash += (int) surveyQuestionId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SurveyQuestionsPK)) {
            return false;
        }
        SurveyQuestionsPK other = (SurveyQuestionsPK) object;
        if (this.surveyId != other.surveyId) {
            return false;
        }
        if (this.surveyQuestionId != other.surveyQuestionId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "osa.ora.beans.SurveyQuestionsPK[ surveyId=" + surveyId + ", surveyQuestionId=" + surveyQuestionId + " ]";
    }
    
}
