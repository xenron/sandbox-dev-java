/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bo;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.beans.NotificationTemplate;
import osa.ora.beans.User;
import osa.ora.dao.AccountDAO;
import osa.ora.dao.CommonDAO;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.AuditTrailVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class AccountBO{    
    @EJB(beanName = "AccountDAO")
    AccountDAO accountDAO;
    @EJB(beanName = "CommonDAO")
    CommonDAO commonDAO;
    /**
     * login method
     * @param username
     * @param password
     * @return 
     */
    public UserVO login(String username, String password) {
        UserVO userDTO = null;
        User user=accountDAO.login(username, password);
        if(user==null){
            Logger.getLogger(AccountBO.class.getName()).log(Level.INFO,"user not found");
            return null;
        }else{
            userDTO = BOMappingHelper.mapUserToUserDTO(user,userDTO);
            AuditTrailVO auditTrail=new AuditTrailVO();
            auditTrail.setActionId(IConstant.USER_LOGIN);
            auditTrail.setUserId(user.getId());
            auditTrail.setDate(new Date());
            auditTrail.setReason("GUI login");
            commonDAO.createAuditTrail(auditTrail);
        }
        return userDTO;
    }

    /**
     * register new user
     * @param username
     * @param password
     * @param email
     * @param url
     * @return
     * @throws Exception
     */
    public UserVO registerUser(String username, String password, String email, String url) throws Exception{
        UserVO userDTO = null;
        User user=accountDAO.registerUser(username, password, email);
        if(user==null){
            Logger.getLogger(AccountBO.class.getName()).log(Level.INFO,"user not registered");
            return null;
        }else{
            //get the user registration notification
            NotificationTemplate template=commonDAO.getNotificationForAction(IConstant.USER_REGISTERED);
            String body = commonDAO.replaceParameters(template.getBody(),new String[]{user.getName(),url});
            //send registration email messages
            commonDAO.sendMail(new String[]{user.getEmail()}, template.getSubject(),body,null, null, false);            
            //send registration email messages
            userDTO = BOMappingHelper.mapUserToUserDTO(user,userDTO);
            AuditTrailVO auditTrail=new AuditTrailVO();
            auditTrail.setActionId(IConstant.USER_REGISTERED);
            auditTrail.setUserId(user.getId());
            auditTrail.setDate(new Date());
            auditTrail.setReason("User registered");
            commonDAO.createAuditTrail(auditTrail);
        }
        return userDTO;
    }

    /**
     * Activate user from email link
     * @param email
     * @param url
     * @return
     */
    public boolean activateUser(String email, String url) {
        User user=accountDAO.activateUser(email);
        if(user==null){
            Logger.getLogger(AccountBO.class.getName()).log(Level.INFO,"user not activated");
            return false;
        }else{
            //get the user activation notification
            NotificationTemplate template=commonDAO.getNotificationForAction(IConstant.USER_ACTIVATED);
            String body = commonDAO.replaceParameters(template.getBody(),new String[]{user.getName(),url});
            //send activation email messages
            commonDAO.sendMail(new String[]{email}, template.getSubject(),body,null, null, false);            
            AuditTrailVO auditTrail=new AuditTrailVO();
            auditTrail.setActionId(IConstant.USER_ACTIVATED);
            auditTrail.setUserId(user.getId());
            auditTrail.setDate(new Date());
            auditTrail.setReason("User activated");
            commonDAO.createAuditTrail(auditTrail);
            return true;
        }
    }
    
}
