/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bo;

import java.util.logging.Level;
import java.util.logging.Logger;
import osa.ora.beans.Configuration;
import osa.ora.beans.QuestionRatingType;
import osa.ora.beans.Questions;
import osa.ora.beans.Survey;
import osa.ora.beans.User;
import osa.ora.dto.ConfigurationVO;
import osa.ora.dto.QuestionVO;
import osa.ora.dto.RatingVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
public class BOMappingHelper {
    /**
     * map user to userVO
     * @param user
     * @param userDTO
     * @return 
     */
    public static UserVO mapUserToUserDTO(User user, UserVO userDTO) {
        Logger.getLogger(BOMappingHelper.class.getName()).log(Level.INFO,"Inside mapping");
        userDTO = new UserVO( user.getId(), user.getName(), user.getEmail(), user.getPassword(), true,user.getRoleId().getId(), user.getRoleId().getRole());
        return userDTO;
    }
    /**
     * map RatingTypes to RatingTypesVO
     * @param ratings
     * @param ratingListVO
     * @return 
     */
    static RatingVO[] mapUserToUserDTO(QuestionRatingType[] ratings, RatingVO[] ratingListVO) {
        ratingListVO = new RatingVO[ratings.length];
        Logger.getLogger(BOMappingHelper.class.getName()).log(Level.INFO,"size="+ratings.length);
        for(int i=0;i<ratings.length;i++){
            RatingVO ratingVO=new RatingVO();
            ratingListVO[i]=ratingVO;
            ratingListVO[i].setId(ratings[i].getId());
            ratingListVO[i].setType(ratings[i].getType());
            ratingListVO[i].setDesc(ratings[i].getDescription());
        }
        return ratingListVO;
    }
    /**
     * map Survey[] to SurveyVO[]
     * @param surveys
     * @param surveyListVO
     * @return 
     */
    static SurveyVO[] mapSurveyToSurveyDTO(Survey[] surveys, SurveyVO[] surveyListVO) {
        surveyListVO = new SurveyVO[surveys.length];
        Logger.getLogger(BOMappingHelper.class.getName()).log(Level.INFO,"size="+surveys.length);
        for(int i=0;i<surveys.length;i++){
            SurveyVO surveyVO=new SurveyVO();
            surveyListVO[i]=surveyVO;
            surveyListVO[i].setId(surveys[i].getId());
            surveyListVO[i].setTitle(surveys[i].getTitle());
            surveyListVO[i].setDescription(surveys[i].getDescription());
            surveyListVO[i].setMaxParticipation(surveys[i].getMaxParticipation());
            surveyListVO[i].setNoOfQuestions(surveys[i].getNoOfQuestions());
            surveyListVO[i].setPrivateFlag(surveys[i].getPrivateFlag());
            surveyListVO[i].setStatus(surveys[i].getStatus());
            surveyListVO[i].setMaxParticipation(surveys[i].getMaxParticipation());
        }
        return surveyListVO;
    }
    /**
     * Map Survey to SurveyVO and fill questions from Question[] to QuestionVO[]
     * @param survey
     * @param questions
     * @return 
     */
    static SurveyVO mapSurveyItemToSurveyDTO(Survey survey, Questions[] questions) {
        SurveyVO surveyDetails = new SurveyVO();
        surveyDetails.setId(survey.getId());
        surveyDetails.setTitle(survey.getTitle());
        surveyDetails.setDescription(survey.getDescription());
        surveyDetails.setMaxParticipation(survey.getMaxParticipation());
        surveyDetails.setNoOfQuestions(survey.getNoOfQuestions());
        surveyDetails.setPrivateFlag(survey.getPrivateFlag());
        surveyDetails.setStatus(survey.getStatus());
        //fill questions in the survey
        QuestionVO[] questionListVO= new QuestionVO[questions.length];
        int i=0;
        for(Questions currentQuestions: questions){
            questionListVO[i]=new QuestionVO();
            questionListVO[i].setId(currentQuestions.getId());
            questionListVO[i].setBody(currentQuestions.getBody());
            questionListVO[i].setQuestion(currentQuestions.getQuestion());
            questionListVO[i].setRatingtypeId(currentQuestions.getRatingtypeId());
            i++;
        }
        surveyDetails.setSurveryQuestions(questionListVO);
        return surveyDetails;
    }
    /**
     * map configuration to configurationVO 
     * @param configs
     * @return 
     */
    static ConfigurationVO[] mapConfigToConfigDTO(Configuration[] configs) {
        ConfigurationVO[] configurationVO= new ConfigurationVO[configs.length];
        int i=0;
        for(Configuration currentConfiguration: configs){
            configurationVO[i]=new ConfigurationVO(currentConfiguration.getConfigkey(), 
                    currentConfiguration.getConfigValue());
            i++;
        }
        return configurationVO;
    }
}
