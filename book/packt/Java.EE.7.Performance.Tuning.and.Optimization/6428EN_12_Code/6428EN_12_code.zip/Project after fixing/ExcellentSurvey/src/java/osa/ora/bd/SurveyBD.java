/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bd;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.bo.SurveyBO;
import osa.ora.dto.RatingVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class SurveyBD {
    @EJB(beanName = "SurveyBO")
    SurveyBO surveyBO;
    /**
     * method to load all question rating types
     * @return 
     */
    public RatingVO[] loadAllRatings(){
        return surveyBO.loadAllRatings();
    }
    /**
     * method to create new survey
     * @param userVO 
     * @param surveyVO 
     * @return 
     */
    public boolean createNewSurvey(UserVO userVO,SurveyVO surveyVO){
        return surveyBO.createNewSurvey(userVO,surveyVO);
    }
    /**
     * method to get all survey list owned by this user
     * @param userVO
     * @return 
     */
    public SurveyVO[] getMySurveyList(UserVO userVO){
        return surveyBO.getMySurveyList(userVO);
    }
    /**
     * method to activate survey and send email to survey mails
     * @param userVO
     * @param surveyId
     * @return 
     */
    public boolean activateSurveyAndSendEmails(UserVO userVO,int surveyId){
        return surveyBO.activateSurveyAndSendEmails(userVO,surveyId);
    }
    /**
     * method to close survey
     * @param userVO
     * @param surveyId
     * @return 
     */
    public boolean closeSurvey(UserVO userVO,int surveyId){
        return surveyBO.closeSurvey(userVO,surveyId);
    }
    /**
     * method to delete survey
     * @param userVO
     * @param surveyId
     * @return 
     */
    public boolean deleteSurvey(UserVO userVO,int surveyId){
        return surveyBO.deleteSurvey(userVO,surveyId);
    }
    /**
     * method to get survey report in HTML format
     * @param userVO
     * @param surveyId
     * @return 
     */
    public String getSurveyReport(UserVO userVO,int surveyId){
        return surveyBO.getSurveyReport(userVO,surveyId);
    }
    /**
     * Method to get all available survey list that the user
     * can vote on them.
     * @param userVO
     * @return 
     */
    public SurveyVO[] getAvailableSurveyList(UserVO userVO) {
        return surveyBO.getAvailableSurveyList(userVO);
    }
    /**
     * Method to get count of surveys owned by this user
     * @param userVO
     * @return 
     */
    public int getUserSurveyCount(UserVO userVO) {
        return surveyBO.getUserSurveyCount(userVO);
    }    /**
     * get survey details for certain survey.
     * @param userVO
     * @param surveyId
     * @return 
     */
    public SurveyVO getSurveyDetails(UserVO userVO, int surveyId) {
        return surveyBO.getSurveyDetails(userVO,surveyId);
     }
    /**
     * method to submit survey answers
     * @param userVO
     * @param userAnswerVOs
     * @param surveyId
     * @return 
     */
    public boolean submitSurveyAnswers(UserVO userVO, UserAnswerVO[] userAnswerVOs,int surveyId) {
        return surveyBO.submitSurveyAnswers(userVO,userAnswerVOs, surveyId);
    }
}
