/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.servlets;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.SurveyBD;
import osa.ora.dao.helper.IConstant;
import osa.ora.dto.QuestionVO;
import osa.ora.dto.RatingVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "CreateServlet", urlPatterns = {"/CreateServlet"})
public class CreateServlet extends HttpServlet {
    @EJB(beanName = "SurveyBD")
    SurveyBD surveyBD;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getParameter("action");
        Logger.getLogger(CreateServlet.class.getName()).log(Level.INFO, "Action="+action);
        request.getSession().removeAttribute("createSurveyError");
        UserVO userAccount = (UserVO)request.getSession().getAttribute("USER");
        //check user survey's count to ensure user didn't create more than max number of surveys
        int surveyCount=surveyBD.getUserSurveyCount(userAccount);
        if(surveyCount>=IConstant.MAX_USER_SURVEYS){
            Logger.getLogger(CreateServlet.class.getName()).log(Level.INFO, "You can't create more than "+IConstant.MAX_USER_SURVEYS+" surveys!, Username="+userAccount.getName());
            request.getSession().setAttribute("ERROR","You can't create more than "+IConstant.MAX_USER_SURVEYS+" surveys!");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;            
        }
        userAccount.setCountOfSurvey(surveyCount);            
        if(action==null || "1".equals(action)){
            String title=request.getParameter("title");
            String isPublic=request.getParameter("public");
            String noOfQuestions=request.getParameter("questions");
            String desc=request.getParameter("desc");
            String max=request.getParameter("max");
            String emails=request.getParameter("emails");
            if(userAccount !=null && title !=null && isPublic!=null && noOfQuestions!=null && desc!=null && max!=null &&
                   !"".equals(title) && !"".equals(isPublic) && !"".equals(noOfQuestions) && !"".equals(max)) {
                //do other checks
                int questions=0;
                try{
                    questions=Integer.parseInt(noOfQuestions);
                }catch(Exception ex){
                }
                int maxParticipants=0;
                try{
                    maxParticipants=Integer.parseInt(max);
                }catch(Exception ex){
                }
                boolean publicFlag=true;
                try{
                    publicFlag=Boolean.parseBoolean(isPublic);
                }catch(Exception ex){
                }
                String[] emailAddresses = null;
                if(emails.length()>0 && emails.indexOf(",")!=-1){
                    emailAddresses=emails.split(",");
                }
                if(questions>0){
                    RatingVO[] ratingTypes=surveyBD.loadAllRatings();
                    request.getSession().setAttribute("QuestionTypes",ratingTypes);
                    SurveyVO newSurvey=new SurveyVO();
                    newSurvey.setTitle(title);
                    newSurvey.setDescription(desc);
                    newSurvey.setNoOfQuestions(questions);
                    newSurvey.setOwnerId(userAccount.getId());
                    newSurvey.setPrivateFlag(publicFlag);
                    newSurvey.setStatus(IConstant.CREATED_STATUS);
                    newSurvey.setMaxParticipation(maxParticipants);
                    newSurvey.setSurveyEmails(emailAddresses);
                    QuestionVO[] surveryQuestions= new QuestionVO[questions];
                    newSurvey.setSurveryQuestions(surveryQuestions);
                    Logger.getLogger(CreateServlet.class.getName()).log(Level.INFO,"Survey:"+title+" desc:"+desc+" ownerId:"+userAccount.getName());
                    request.getSession().setAttribute("survey",newSurvey);
                    request.getRequestDispatcher("/submitquestions.jsp").forward(request, response);
                }else{
                    request.getSession().setAttribute("createSurveyError","invalid");
                    request.getRequestDispatcher("/create.jsp").forward(request, response);
                }
            } else{
                request.getRequestDispatcher("/create.jsp").forward(request, response);                
            }
        }else if("2".equals(action)){
            SurveyVO newSurvey=(SurveyVO)request.getSession().getAttribute("survey");
            if(newSurvey!=null){
                QuestionVO[] surveryQuestions=new QuestionVO[newSurvey.getNoOfQuestions()];
                for(int i=1;i<=newSurvey.getNoOfQuestions();i++){
                    String question=request.getParameter("question_"+i);
                    String body=request.getParameter("body_"+i);
                    String type=request.getParameter("type_"+i);
                    Logger.getLogger(CreateServlet.class.getName()).log(Level.INFO, "Q "+i+" = "+question+" - "+body+" - "+type);
                    QuestionVO surveryQuestion=new QuestionVO();
                    surveryQuestion.setBody(body);
                    surveryQuestion.setQuestion(question);
                    surveryQuestion.setRatingtypeId(Integer.parseInt(type));
                    surveryQuestion.setSequence(i);
                    surveryQuestions[i-1]=surveryQuestion;
                }
                newSurvey.setSurveryQuestions(surveryQuestions);
                boolean success=surveyBD.createNewSurvey(userAccount, newSurvey);
                if(success){
                    request.getRequestDispatcher("/confirm.jsp").forward(request, response);
                    //surveyCount=surveyBD.getUserSurveyCount(userAccount);
                    userAccount.setCountOfSurvey(surveyCount+1);
                    request.getSession().setAttribute("USER", userAccount);
                    return;
                }else{
                    request.getSession().setAttribute("ERROR","Invalid survey configurations");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);
                    return;
                }
            }
            request.getSession().setAttribute("ERROR","Invalid survey configurations");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }else{
            request.getSession().setAttribute("ERROR","Invalid survey configurations");
            request.getRequestDispatcher("/error.jsp").forward(request, response);            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
