/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.bd;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import osa.ora.bo.AccountBO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class AccountBD {
    @EJB(beanName = "AccountBO")
    AccountBO accountBO;
    /**
     * login user
     * @param username
     * @param password
     * @return 
     */
    public UserVO login(String username, String password) {
        return accountBO.login(username, password);
    }
    /**
     * register new user
     * @param username
     * @param password
     * @param email
     * @return
     * @throws Exception 
     */
    public UserVO registerUser(String username, String password, String email, String url) throws Exception {
        return accountBO.registerUser(username, password,email, url);
    }
    /**
     * activate registered user
     * @param email
     * @param url
     * @return 
     */
    public boolean activateUser(String email, String url) {
        return accountBO.activateUser(email, url);
    }
    
}
