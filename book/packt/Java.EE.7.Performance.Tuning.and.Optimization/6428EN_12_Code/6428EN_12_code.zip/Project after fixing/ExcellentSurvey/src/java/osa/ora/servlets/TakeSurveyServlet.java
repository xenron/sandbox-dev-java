/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428).
 */

package osa.ora.servlets;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import osa.ora.bd.SurveyBD;
import osa.ora.dto.QuestionVO;
import osa.ora.dto.SurveyVO;
import osa.ora.dto.UserAnswerVO;
import osa.ora.dto.UserVO;

/**
 *
 * @author Osama Oransa
 */
@WebServlet(name = "TakeSurveyServlet", urlPatterns = {"/TakeSurveyServlet"})
public class TakeSurveyServlet extends HttpServlet {
    @EJB(beanName = "SurveyBD")
    SurveyBD surveyBD;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getParameter("action");
        Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "Action="+action);
        UserVO userAccount = (UserVO)request.getSession().getAttribute("USER");
        if(action==null || "1".equals(action)){ //list all surveys
            SurveyVO[] mySurveys=surveyBD.getAvailableSurveyList(userAccount);
            request.getSession().setAttribute("SURVEYLIST", mySurveys);
            request.getRequestDispatcher("/surveylist.jsp").forward(request, response);
        }else if("2".equals(action)){ //take survey
            String id=request.getParameter("id");
            if(id==null){
                    request.getSession().setAttribute("ERROR","Invalid survey ID!");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);                    
            }else {
                int surveyId=-1;
                try{
                    surveyId=Integer.parseInt(id);
                }catch(NumberFormatException ex){
                }
                SurveyVO surveyDetails=surveyBD.getSurveyDetails(userAccount,surveyId);
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "questions size"+surveyDetails.getSurveryQuestions().length);
                for(QuestionVO question:surveyDetails.getSurveryQuestions()){
                    Logger.getLogger(RegisterServlet.class.getName()).log(Level.INFO, "--"+question.getQuestion());
                }
                if(surveyDetails!=null){
                    request.getSession().setAttribute("SURVEYDETAILS",surveyDetails);
                    request.getRequestDispatcher("/details.jsp").forward(request, response);                    
                }else {
                    request.getSession().setAttribute("ERROR","Can't retireve this survey!");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);                    
                }
            }
        }else if("3".equals(action)){ //submit survey
            SurveyVO surveyDetails=(SurveyVO)request.getSession().getAttribute("SURVEYDETAILS");
            QuestionVO[] questions=surveyDetails.getSurveryQuestions();
            UserAnswerVO[] userAnswerVOs=new UserAnswerVO[questions.length];
            int i=0;
            for(QuestionVO question:questions){
                String answer=request.getParameter("q"+question.getId());
                userAnswerVOs[i]=new UserAnswerVO();
                userAnswerVOs[i].setAnswer(Integer.parseInt(answer));
                userAnswerVOs[i].setQuestionId(question.getId());
                i++;
            }
            boolean submitted=surveyBD.submitSurveyAnswers(userAccount,userAnswerVOs, surveyDetails.getId());
            if(submitted){
                request.getSession().removeAttribute("SURVEYDETAILS");
                request.getRequestDispatcher("/submitted.jsp").forward(request, response);                    
            }else {
                request.getSession().setAttribute("ERROR","Can't submot this survey, you may try later!");
                request.getRequestDispatcher("/error.jsp").forward(request, response);                    
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
