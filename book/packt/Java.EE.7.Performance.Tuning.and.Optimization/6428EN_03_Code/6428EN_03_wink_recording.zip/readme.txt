To use the recorded wink file, open the test.htm by any browser.
