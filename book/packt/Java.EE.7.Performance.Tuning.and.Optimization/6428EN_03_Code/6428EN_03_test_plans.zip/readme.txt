The .jmx files are the files we used in JMeter in chapter 3 to do test plans, you can use them by the following steps:
1- Run JMeter
2- File --> Open --> and select any of these files
3- Point to the correct .csv files from "CSV config data" elements to the included files: testroles.csv and testusers.csv
4- Run the required services : mySQL and Glassfish server
5- Execute the test plans.
