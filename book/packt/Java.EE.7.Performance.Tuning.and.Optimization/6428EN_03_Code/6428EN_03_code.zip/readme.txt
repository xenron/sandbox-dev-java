This is a NetBeans project, that need to be imported from insdie NetBeans.

1) Open NetBeans 7.x
2) From File select -->Open Project 
Navigate to this project folder and select it.
3) The project will open, you can now run it from inside NetBeans.

The project have 2 main methods:
BankOperation.java : here implicit lock is used.
BankOperationWithLock.java : here explicit Lock object is used for locking.
