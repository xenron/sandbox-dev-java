/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428)
 */
package osa.ora.helper;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import osa.ora.entities.Account;
import osa.ora.entities.UserRole;

/**
 *
 * @author Osama Oransa
 */
@Stateless
public class DataHelperSessionBean {

    @PersistenceContext(unitName = "ExampleOnePU")
    EntityManager em;

    /**
     * Method to authenticate user by username and password
     *
     * @param username
     * @param password
     * @return boolean true/false if user is authenticated or not
     */
    public boolean authenticateUser(String username, String password) {
        //We can use named query or create the query
        Query query = em.createNamedQuery("Account.authenticate");
        //Query query = em.createQuery("SELECT a FROM Account a WHERE a.username = :username AND a.password = :password AND a.active = 0", Account.class);
        query.setParameter("username", username);
        query.setParameter("password", password);
        List<Account> results = query.getResultList();
        try {
            //random wait to have some performance results
            Thread.sleep(ThreadLocalRandom.current().nextInt(500));
        } catch (InterruptedException ex) {
        }
        if (results != null && results.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Method to authenticate user by username and password
     *
     * @param username
     * @param password
     * @return Account object that hold user account details
     */
    public Account authenticateUserObject(String username, String password) {
        //TODO: we can use named query instead of creating the query each time
        Query query = em.createNamedQuery("Account.authenticate");
        query.setParameter("username", username);
        query.setParameter("password", password);
        List<Account> results = query.getResultList();
        try {
            //random wait to have some performance results
            Thread.sleep(ThreadLocalRandom.current().nextInt(500));
        } catch (InterruptedException ex) {
        }
        if (results != null && results.size() > 0) {
            return results.get(0);
        }
        return null;
    }

    /**
     * method to load all user roles
     *
     * @return UserRole[] array of user roles
     */
    public UserRole[] loadAllUserRoles() {
        //TODO: global caching is required for such collections
        UserRole[] results = new UserRole[0];
        Query query = em.createNamedQuery("UserRole.findAll");
        results = (UserRole[]) query.getResultList().toArray(results);
        return results;
    }

    /**
     * Save account with the new assigned roleId
     *
     * @param account
     * @param roleId
     * @return Account object with the recent user account details.
     */
    public Account saveAccount(Account account, int roleId) {
        //TODO: a check need to be placed here to check if it is the same roleId or new one
        Account currentAccount = (Account) em.find(Account.class, account.getId());
        UserRole newRole = (UserRole) em.find(UserRole.class, roleId);
        currentAccount.setRoleId(newRole);
        return account;
    }

}
