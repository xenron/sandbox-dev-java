/*
 * Written by Osama Oransa
 * This project is written for the book
 * Java Enterprise Edition 7 Performance Tuning (EN6428)
 */
package osa.ora;

import javax.ejb.EJB;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import osa.ora.helper.DataHelperSessionBean;

/**
 *
 * @author Osama Oransa
 */
@WebService(serviceName = "ExampleWebService")
@Stateless()
public class ExampleWebService {

    @EJB(beanName = "DataHelperSessionBean")
    DataHelperSessionBean dataHelperSessionBean;

    /**
     * authenticateUser web service operation
     *
     * @param username
     * @param password
     * @return boolean
     */
    @WebMethod(operationName = "authenticateUser")
    public boolean authenticateUser(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return dataHelperSessionBean.authenticateUser(username, password);
    }

}
