package org.coffeeshop;

/**
 * A basic class to indicate preference for coffee
 * @author Bhakti Mehta
 */
public enum Preference {
    NonFat, Regular, Lowfat;
}
