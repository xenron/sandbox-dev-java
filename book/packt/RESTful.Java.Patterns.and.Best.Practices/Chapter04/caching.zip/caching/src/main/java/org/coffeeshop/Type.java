package org.coffeeshop;

/**
 * This is the type of coffee to be ordered
 */
public enum Type {
    Expresso, Brewed, Blended, Chocolate ;

}
