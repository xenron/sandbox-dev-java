package web;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import business.MessageBO;
import exception.ItemNotFoundException;

public class MessageResource extends Resource {
	public MessageResource(Context context, Request request, Response response) {
		super(context, request, response);

		getVariants().add(new Variant(MediaType.APPLICATION_XML));
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
	}

	@Override
	public boolean allowGet() {
		return true;
	}

	@Override
	public Representation represent(Variant variant) throws ResourceException {
		Representation representation = null;
		String messageID = (String) getRequest().getAttributes().get("messageID");

		if (MediaType.APPLICATION_XML.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.getXML(messageID), MediaType.APPLICATION_XML);
		} else if (MediaType.APPLICATION_JSON.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.getJSON(messageID), MediaType.APPLICATION_JSON);
		}
		
		return representation;
	}
	
	// HTTP DELETE
	@Override
	public boolean allowDelete() {
		return true;
	}

	@Override
	public void removeRepresentations() throws ResourceException {
		try {
			String messageID = (String) getRequest().getAttributes().get("messageID");
			MessageBO.delete(messageID);
			getResponse().setStatus(Status.SUCCESS_NO_CONTENT);
		} catch (ItemNotFoundException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
		}		
	}	
}
