package web;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import business.MessageBO;

public class SearchMessagesResource extends Resource {
	public SearchMessagesResource(Context context, Request request, Response response) {
		super(context, request, response);

		// We need 2 media types: XML and JSON
		getVariants().add(new Variant(MediaType.APPLICATION_XML));
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
	}

	@Override
	public boolean allowGet() {
		return true;
	}

	@Override
	public Representation represent(Variant variant) throws ResourceException {
		Representation representation = null;
		String search_item = (String) getRequest().getAttributes().get("search_item");

		if (MediaType.APPLICATION_XML.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.searchAllXML(search_item), MediaType.APPLICATION_XML);
		} else if (MediaType.APPLICATION_JSON.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.searchAllJSON(search_item), MediaType.APPLICATION_JSON);
		}
		
		return representation;
	}

	// Note that allowPost(), allowPut(), allowDelete(), all default to false;
	// therefore there's no need to implicitly override them
}
