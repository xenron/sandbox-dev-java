package web;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import exception.InvalidXMLException;
import exception.ItemAlreadyExistsException;

import business.UserBO;

public class UsersResource extends Resource {
	public UsersResource(Context context, Request request, Response response) {
		super(context, request, response);

		getVariants().add(new Variant(MediaType.APPLICATION_XML));
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
	}

	// We need all CRUD-like calls

	// Think of them as going is pairs
	// HTTP GET
	@Override
	public boolean allowGet() {
		return true;
	}

	@Override
	public Representation represent(Variant variant) throws ResourceException {
		Representation representation = null;	

		if (MediaType.APPLICATION_XML.equals(variant.getMediaType())) {
			representation = new StringRepresentation(UserBO.getAllXML(), MediaType.APPLICATION_XML);
		} else if (MediaType.APPLICATION_JSON.equals(variant.getMediaType())) {
			representation = new StringRepresentation(UserBO.getAllJSON(), MediaType.APPLICATION_JSON);
		}
		
		return representation;
	}

	// HTTP POST
	@Override
	public boolean allowPost() {
		return true;
	}

	// Handle the post
	@Override
	public void acceptRepresentation(Representation entity) throws ResourceException {	
		try {
			Representation representation = new StringRepresentation(UserBO.create(entity.getText()), MediaType.APPLICATION_XML);
			getResponse().setEntity(representation);
		} catch (InvalidXMLException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_BAD_REQUEST);
		} catch (ItemAlreadyExistsException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_FORBIDDEN);
		} catch (IOException e) {
			getResponse().setStatus(Status.SERVER_ERROR_INTERNAL );			
		}		
	}
}
