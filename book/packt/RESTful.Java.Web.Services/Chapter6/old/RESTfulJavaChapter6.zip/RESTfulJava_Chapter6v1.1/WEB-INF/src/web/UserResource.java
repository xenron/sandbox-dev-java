package web;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import exception.InvalidXMLException;
import exception.ItemNotFoundException;

import business.UserBO;

public class UserResource extends Resource {
	public UserResource(Context context, Request request, Response response) {
		super(context, request, response);

		getVariants().add(new Variant(MediaType.APPLICATION_XML));
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
	}

	// We need all CRUD-like calls

	// Think of them as going is pairs
	// HTTP GET
	@Override
	public boolean allowGet() {
		return true;
	}

	@Override
	public Representation represent(Variant variant) throws ResourceException {
		Representation representation = null;
		String username = (String) getRequest().getAttributes().get("username");

		if (MediaType.APPLICATION_XML.equals(variant.getMediaType())) {
			representation = new StringRepresentation(UserBO.getXML(username), MediaType.APPLICATION_XML);
		} else if (MediaType.APPLICATION_JSON.equals(variant.getMediaType())) {
			representation = new StringRepresentation(UserBO.getJSON(username), MediaType.APPLICATION_JSON);
		}
		
		return representation;
	}

	// HTTP PUT
	@Override
	public boolean allowPut() {
		return true;
	}

	@Override
	public void storeRepresentation(Representation entity) throws ResourceException {
		try {
			Representation representation = new StringRepresentation(UserBO.update(entity.getText()), MediaType.APPLICATION_XML);
			getResponse().setEntity(representation);
		} catch (InvalidXMLException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_BAD_REQUEST);
		} catch (ItemNotFoundException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
		} catch (IOException e) {
			getResponse().setStatus(Status.SERVER_ERROR_INTERNAL );
		}
	}

	// HTTP DELETE
	@Override
	public boolean allowDelete() {
		return true;
	}

	@Override
	public void removeRepresentations() throws ResourceException {
		try {
			String username = (String) getRequest().getAttributes().get("username");
			UserBO.delete(username);
			getResponse().setStatus(Status.SUCCESS_NO_CONTENT);
		} catch (ItemNotFoundException e) {
			getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
		}
	}
}
