package web;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import business.MessageBO;

public class UserMessagesResource extends Resource {
	public UserMessagesResource(Context context, Request request, Response response) {
		super(context, request, response);

		// We need 2 media types: XML and JSON
		getVariants().add(new Variant(MediaType.APPLICATION_XML));
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
	}

	@Override
	public boolean allowGet() {
		return true;
	}

	@Override
	public Representation represent(Variant variant) throws ResourceException {
		Representation representation = null;
		String username = (String) getRequest().getAttributes().get("username");

		if (MediaType.APPLICATION_XML.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.getAllXMLForUser(username), MediaType.APPLICATION_XML);
		} else if (MediaType.APPLICATION_JSON.equals(variant.getMediaType())) {
			representation = new StringRepresentation(MessageBO.getAllJSONForUser(username), MediaType.APPLICATION_JSON);
		}
		
		return representation;
	}

	// Note that allowPost(), allowPut(), allowDelete(), all default to false;
	// therefore there's no need to implicitly override them
}
