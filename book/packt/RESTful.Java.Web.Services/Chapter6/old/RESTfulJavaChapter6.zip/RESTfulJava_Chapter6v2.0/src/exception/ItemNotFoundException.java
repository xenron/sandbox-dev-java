package exception;

public class ItemNotFoundException extends Exception {
}
