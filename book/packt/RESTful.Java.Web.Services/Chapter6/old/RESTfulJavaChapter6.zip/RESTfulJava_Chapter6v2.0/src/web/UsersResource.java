package web;

import java.io.IOException;

import org.restlet.data.MediaType;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import business.UserBO;
import exception.InvalidXMLException;
import exception.ItemAlreadyExistsException;

public class UsersResource extends ServerResource {

	// TODO: I think I need to override handle(), like in:
	// http://www.javaworld.com/javaworld/jw-12-2008/jw-12-rest-series-2.html?page=4

	@Get("xml")
	public Representation getXML() {
		String xml = UserBO.getAllXML();
		Representation representation = new StringRepresentation(xml, MediaType.APPLICATION_XML);

		return representation;
	}

	// TODO: this doesn't work...The Accept header is not properly handled by Restlet
	@Get("json")
	public Representation getJSON() {
		String json = UserBO.getAllJSON();
		Representation representation = new StringRepresentation(json, MediaType.APPLICATION_JSON);

		return representation;
	}

	// Representation holds the actual representation
	// A Restlet represetnation holds true to the REST archetype: a
	// representation together
	// with metadata about the represtantion
	// file:///C:/jose/java/restlet/restlet-1.2m2/docs/api/index.html
	@Post
	public Representation createtUser(Representation entity) {
		Representation representation = null;
		
		try {
			representation = new StringRepresentation(UserBO.create(entity.getText()), MediaType.APPLICATION_XML);
		} catch (InvalidXMLException e) {
			setStatus(Status.CLIENT_ERROR_BAD_REQUEST);
			representation = new StringRepresentation("Invalid XML.", MediaType.TEXT_PLAIN);
		} catch (ItemAlreadyExistsException e) {
			setStatus(Status.CLIENT_ERROR_FORBIDDEN);
			representation = new StringRepresentation("Item already exists.", MediaType.TEXT_PLAIN);
		} catch (IOException e) {
			setStatus(Status.SERVER_ERROR_INTERNAL );			
		}

		return representation;
	}
}
