package exception;

public class UserNotFoundException extends Exception {

}
