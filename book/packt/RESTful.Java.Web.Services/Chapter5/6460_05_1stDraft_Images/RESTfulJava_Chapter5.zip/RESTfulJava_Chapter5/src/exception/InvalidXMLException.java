package exception;

public class InvalidXMLException extends Exception {
}
