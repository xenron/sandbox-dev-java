package business;

public interface Constants {
	public static final String DB_NAME = "c:\\temp\\db2.data";

}
