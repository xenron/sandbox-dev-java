package exception;

public class ItemAlreadyExistsException extends Exception {
}
